#!/usr/bin/env python3
"""
Runtime smoke test: actually LOAD the packaged jar and boot Myau's module system.

Stubs out just enough of Minecraft/Forge to satisfy class initialisation, then
reflectively constructs myau.Myau and asserts every registered module exists, is
enabled/disabled correctly, and exposes its properties through Myau's own
PropertyManager. This exercises the real code paths (constructor -> property
registration -> EventManager registration) without a GPU or game.
"""
import glob, json, os, re, subprocess, sys, tempfile, zipfile

# NOTE: the *shipped* jar is SRG-remapped (it calls net.minecraft.func_71410_x etc.), which
# only resolves against an obfuscated Minecraft. To exercise the real code here we boot the
# MCP-named intermediate jar from the same build, against mcp-mapped Minecraft. Same classes,
# same wiring - only the name mapping differs.
JAR = sys.argv[1] if len(sys.argv) > 1 else \
    "/root/work/MyauMerged/build/intermediates/MyauFix-1.6-non-obfuscated-with-deps.jar"
WORK = tempfile.mkdtemp(prefix="myau-boot-")
z = zipfile.ZipFile(JAR)
z.extractall(WORK)

MC_JAR = "/root/OpenJade/JadeClient/lib/minecraft-1.8.9-mcp.jar"
STUB = os.path.join(WORK, "_stub")
os.makedirs(os.path.join(STUB, "myau"), exist_ok=True)

# ---------------------------------------------------------------- the harness
HARNESS = r'''
import java.lang.reflect.*;
import java.util.*;

public class Boot {
    static int failures = 0;
    static void ok(boolean c, String m) {
        System.out.println((c ? "  OK   " : "  FAIL ") + m);
        if (!c) failures++;
    }

    public static void main(String[] a) throws Exception {
        Class<?> myauCls = null;
        try {
            myauCls = Class.forName("myau.Myau");
        } catch (Throwable t) {
            System.out.println("  FAIL cannot load myau.Myau: " + t);
            System.exit(1);
        }
        System.out.println("  OK   myau.Myau loaded");

        // Minecraft's own startup sequence: Blocks/Items/Stats static initialisers
        // throw "Accessed Blocks before Bootstrap!" unless the registry is bootstrapped
        // first. The real client does this in Minecraft.startGame().
        try {
            Class.forName("net.minecraft.init.Bootstrap").getMethod("register")
                    .invoke(null);
            ok(true, "Minecraft Bootstrap.register() succeeded");
        } catch (Throwable t) {
            Throwable c = t.getCause() != null ? t.getCause() : t;
            System.out.println("  FAIL Minecraft Bootstrap.register(): " + c);
            for (Throwable d = c; d != null; d = d.getCause()) {
                StackTraceElement[] st = d.getStackTrace();
                for (int i = 0; i < Math.min(8, st.length); i++) System.out.println("        at " + st[i]);
                if (d.getCause() == d) break;
            }
            System.exit(1);
        }

        Object myau = myauCls.getDeclaredConstructor().newInstance();

        Object mm = myauCls.getField("moduleManager").get(myau);
        Field modsF = mm.getClass().getField("modules");
        Map<?, ?> mods = (Map<?, ?>) modsF.get(mm);

        Class<?> moduleBase = Class.forName("myau.module.Module");
        int total = mods.size();
        ok(total > 200, "module manager holds " + total + " modules");

        // split Myau's own vs imported
        List<Object> osk = new ArrayList<>();
        List<Object> own = new ArrayList<>();
        for (Object m : mods.values()) {
            (m.getClass().getName().startsWith("openskid.") ? osk : own).add(m);
        }
        ok(own.size() == 135, "Myau's own modules intact: " + own.size() + " (expected 135)");
        ok(osk.size() == 128, "imported OpenSkid modules registered: " + osk.size() + " (expected 128)");

        // every imported module: correct base class, non-null name, prefix
        int bad = 0, noprefix = 0, noname = 0, descmissing = 0;
        Set<String> seen = new HashSet<>();
        Set<String> dupes = new HashSet<>();
        for (Object m : osk) {
            if (!moduleBase.isInstance(m)) { bad++; continue; }
            Method gn = m.getClass().getMethod("getName");
            String nm = (String) gn.invoke(m);
            if (nm == null || nm.isEmpty()) noname++;
            else {
                if (!nm.startsWith("openskid-")) noprefix++;
                if (!seen.add(nm)) dupes.add(nm);
            }
            Method gd = m.getClass().getMethod("getDescription");
            if (gd.invoke(m) == null) descmissing++;
        }
        ok(bad == 0, "all imported modules extend myau.module.Module" + (bad > 0 ? " (" + bad + " bad)" : ""));
        ok(noname == 0, "all imported modules have a name");
        ok(noprefix == 0, "all imported modules carry the openskid- prefix"
                + (noprefix > 0 ? " (" + noprefix + " without)" : ""));
        ok(dupes.isEmpty(), "imported display names unique" + (dupes.isEmpty() ? "" : " " + dupes));
        ok(descmissing <= 4, "descriptions present on imported modules (missing " + descmissing + ")");

        // Myau's own modules kept their ORIGINAL names (no openskid- contamination)
        int contaminated = 0;
        for (Object m : own) {
            String nm = (String) m.getClass().getMethod("getName").invoke(m);
            if (nm.startsWith("openskid-")) contaminated++;
        }
        ok(contaminated == 0, "no existing Myau module was renamed"
                + (contaminated > 0 ? " (" + contaminated + " renamed!)" : ""));

        // property manager saw every module
        Object pm = myauCls.getField("propertyManager").get(myau);
        Map<?, ?> props = (Map<?, ?>) pm.getClass().getField("properties").get(pm);
        ok(props.size() >= mods.size(),
                "property manager covers all modules (" + props.size() + " >= " + mods.size() + ")");

        int withProps = 0, empty = 0;
        for (Map.Entry<?, ?> e : props.entrySet()) {
            List<?> l = (List<?>) e.getValue();
            if (l.isEmpty()) empty++; else withProps++;
        }
        ok(withProps > 100, withProps + " modules expose properties (" + empty + " with none)");

        // event manager registered them
        Class<?> em = Class.forName("myau.event.EventManager");
        Field reg = em.getDeclaredField("REGISTRY_MAP");
        reg.setAccessible(true);
        Map<?, ?> regMap = (Map<?, ?>) reg.get(null);
        ok(!regMap.isEmpty(), "event registry populated (" + regMap.size() + " event types)");

        // singletons the imported modules rely on
        ok(myauCls.getField("lagCore").get(myau) != null, "lagCore singleton initialised");
        ok(myauCls.getField("fontManagers").get(myau) != null, "fontManagers singleton initialised");

        // every event handler in an imported module resolves to a real method
        int handlers = 0, missingHandlers = 0;
        for (Object m : osk) {
            for (Method mm2 : m.getClass().getDeclaredMethods()) {
                if (mm2.getAnnotation((Class) Class.forName("myau.event.EventTarget")) != null) {
                    handlers++;
                    try { mm2.setAccessible(true); mm2.getParameterTypes(); }
                    catch (Throwable t) { missingHandlers++; }
                }
            }
        }
        ok(handlers > 800, "imported modules expose " + handlers + " event handlers");
        ok(missingHandlers == 0, "all event handlers resolve");

        // toggling: enable/disable round trip must not throw
        int toggled = 0;
        for (Object m : osk) {
            try {
                m.getClass().getMethod("toggle").invoke(m);
                m.getClass().getMethod("toggle").invoke(m);
                toggled++;
            } catch (Throwable t) {
                ok(false, "toggle threw for " + m.getClass().getSimpleName() + ": " + t);
                break;
            }
        }
        ok(toggled == osk.size(), "all " + toggled + " imported modules toggle cleanly");

        System.out.println(failures == 0 ? "\nBOOT OK" : "\nBOOT FAILURES: " + failures);
        System.exit(failures == 0 ? 0 : 1);
    }
}
'''
open(os.path.join(STUB, "Boot.java"), "w").write(HARNESS)

# The Minecraft jar Loom itself compiled this project against (MCP-named, 1.8.9).
# MCP-named Minecraft: the same mapping Loom compiles this project against.
# MCP-named Minecraft + Forge, produced by Loom for exactly this project's mappings.
# (The Jade mcp jar is partly SRG-mapped and blows up in RegistryNamespaced.<init>.)
LOOM = ("/root/.gradle/caches/essential-loom/1.8.9/"
        "de.oceanlabs.mcp.mcp_stable.1_8_9.22-1.8.9-forge-1.8.9-11.15.1.2318-1.8.9")
MC = os.path.join(LOOM, "minecraft-mapped.jar")
if not os.path.isfile(MC):
    sys.exit("Minecraft jar not found: " + MC)

# Real Forge is deliberately NOT on the boot classpath: FMLCommonHandler.<clinit> builds
# the whole mod list and needs a live FML environment. The packaged jar ships a Forge
# shim (net/minecraftforge/**) precisely so the client runs without Forge, so we use
# that - which is also what the inject/attach path does in production.
SHIM_SRC = "/tmp/opencode/myau-build/package/MyauFix-1.6.jar"
if os.path.isfile(SHIM_SRC):
    with zipfile.ZipFile(SHIM_SRC) as _z:
        for _n in _z.namelist():
            if _n.endswith(".class") and (_n.startswith("net/minecraftforge/")
                                          or _n.startswith("org/apache/commons/")):
                _t = os.path.join(WORK, _n)
                os.makedirs(os.path.dirname(_t), exist_ok=True)
                open(_t, "wb").write(_z.read(_n))
FORGE = ""

# Loom's runtime deps. Minecraft's static initialisers reference LWJGL / log4j / guava /
# ICU even though we never create a GL context, so they must be resolvable here.
GRADLE_MODS = "/root/.gradle/caches/modules-2/files-2.1"
WANT = ("org.lwjgl.lwjgl", "com.google.guava", "org.apache.logging.log4j",
        "net.java.dev.jna", "net.sf.jopt-simple", "com.google.code.gson",
        "io.netty", "commons-io", "commons-codec", "org.apache.httpcomponents",
        "org.ow2.asm", "com.paulscode", "org.apache.commons", "it.unimi.dsi",
        "org.jline", "net.java.jinput", "net.minecraft", "com.google.jimfs", "com.ibm.icu")
DEPS = []
for g in os.listdir(GRADLE_MODS):
    if not any(g == w or g.startswith(w + ".") for w in WANT):
        continue
    for j in glob.glob(os.path.join(GRADLE_MODS, g, "**", "*.jar"), recursive=True):
        if j.endswith(("-sources.jar", "-javadoc.jar")):
            continue
        DEPS.append(j)
DEPS = sorted(set(DEPS))

# No-op GL stubs go FIRST so module constructors that build shader programs can run
# without a GL context (see make_gl_stubs.py).
GLSTUB = "/tmp/myau-glstub-classes"
if not os.path.isdir(GLSTUB):
    sys.exit("GL stubs missing; run: python3 make_gl_stubs.py /tmp/myau-glstub && javac ...")
DEPS = [GLSTUB] + [d for d in DEPS
                   if "/org.lwjgl.lwjgl/" not in d]   # real LWJGL would dlopen natives
DEPS_CP = ":".join(DEPS)
CP = ":".join([WORK, MC, JAR] + DEPS)

print(f"jar: {JAR}")
print(f"deps: {len(DEPS)} jars (incl. GL stubs) on the boot classpath\n")

javac = "/usr/lib/jvm/java-8-openjdk-amd64/bin/javac"
java = "/usr/lib/jvm/java-8-openjdk-amd64/bin/java"

# -proc:none: the jar carries Mixin's annotation processor on its service path, which
# would otherwise try to build a refmap for the harness and need gson on the compile path.
r = subprocess.run([javac, "-nowarn", "-proc:none", "-cp", CP, "-d", STUB,
                    os.path.join(STUB, "Boot.java")],
                   capture_output=True, text=True)
if r.returncode != 0:
    print("harness compile failed:\n" + r.stderr[:3000])
    sys.exit(2)

r = subprocess.run([java, "-cp", ":".join([STUB, WORK, MC, DEPS_CP]), "Boot"],
                   capture_output=True, text=True, timeout=300)
print(r.stdout)
if r.returncode != 0 and r.stderr.strip():
    print("--- stderr (tail) ---")
    print("\n".join(r.stderr.strip().split("\n")[-25:]))
sys.exit(r.returncode)