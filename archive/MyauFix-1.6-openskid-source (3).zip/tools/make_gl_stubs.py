#!/usr/bin/env python3
"""
Generate byte-compatible no-op stubs for the org.lwjgl classes the client touches.

Hand-written stubs drifted from the real LWJGL signatures (e.g. GL20.glCreateProgram()
has no args, not varargs), which produces NoSuchMethodError at runtime. So the real
signatures are read straight out of LWJGL with javap and reproduced exactly:
correct name, return type and parameter types, with an empty body.
"""
import os, re, subprocess, sys

STUB = sys.argv[1] if len(sys.argv) > 1 else "/tmp/myau-glstub"
LWJGL_JAR = "/root/.gradle/caches/modules-2/files-2.1/org.lwjgl.lwjgl/lwjgl/2.9.4-nightly-20150209/697517568c68e78ae0b4544145af031c81082dfe/lwjgl-2.9.4-nightly-20150209.jar"
JAVAP = "/usr/lib/jvm/java-8-openjdk-amd64/bin/javap"

# Classes we stub. Everything else stays on the real LWJGL jar (only these are
# removed from the boot classpath).
TARGETS = [
    "org.lwjgl.opengl.GL20", "org.lwjgl.opengl.GL11", "org.lwjgl.opengl.GL14",
    "org.lwjgl.opengl.GL30", "org.lwjgl.opengl.GL", "org.lwjgl.opengl.GLU",
    "org.lwjgl.opengl.GLContext", "org.lwjgl.opengl.DisplayMode",
    "org.lwjgl.opengl.PixelFormat", "org.lwjgl.opengl.ContextCapabilities",
    "org.lwjgl.opengl.LWJGLException",
    "org.lwjgl.opengl.Display", "org.lwjgl.input.Mouse", "org.lwjgl.input.Keyboard",
    "org.lwjgl.BufferUtils", "org.lwjgl.util.glu32",
    "org.lwjgl.opengl.Drawable", "org.lwjgl.opengl.Window",
    "org.lwjgl.opengles.GL20", "org.lwjgl.opengles.ContextAttribs",
    "org.lwjgl.opengl.ContextAttribs", "org.lwjgl.opengl.PixelFormatLWJGL",
    "org.lwjgl.input.Cursor", "org.lwjgl.PointerBuffer", "org.lwjgl.PointerWrapper",
    "org.lwjgl.LWJGLException", "org.lwjgl.LwjglException", "org.lwjgl.Sys",
    "org.lwjgl.opengl.OpenGLException",
]

# Non-zero returns so "did the GL call succeed?" checks pass and constructors
# proceed past the link check.
RETURN_NONZERO = {
    "glCreateProgram", "glCreateShader", "glGetProgrami", "glGetShaderi",
    "glGetUniformLocation", "glGetAttribLocation", "glGetError", "glCheckFramebufferStatus",
}
# Methods whose return value drives control flow but has no meaningful "success" value.
RETURN_SPECIAL = {
    # float queries
    "glGetFloat": "0.0f", "glGetFloatv": None,
}


def parse(cls):
    out = subprocess.run([JAVAP, "-cp", LWJGL_JAR, cls],
                         capture_output=True, text=True).stdout
    methods, consts, ctors = [], {}, []
    for line in out.splitlines():
        line = line.strip().rstrip(";")
        if line.startswith("public static final int"):
            m = re.match(r"public static final int (\w+)", line)
            if m:
                consts[m.group(1)] = None          # value irrelevant for stubs
            continue

        def split_params(params):
            if not params.strip():
                return []
            out_types = []
            for p in params.split(","):
                p = p.strip()
                # drop the parameter name, keep the type
                out_types.append(p.rsplit(" ", 1)[0].strip())
            return out_types

        # constructor: javap prints it as `public <fqcn>(args);`
        mc = re.match(r"public " + re.escape(cls) + r"\((.*)\)", line)
        if mc:
            ctors.append(split_params(mc.group(1)))
            continue
        m = re.match(r"public (?:static )?(\S+) (\w+)\((.*)\)", line)
        if m:
            ret, name, params = m.group(1), m.group(2), m.group(3)
            methods.append((ret, name, split_params(params)))
    return consts, methods, ctors


# primitive/array defaults so we can synthesise plausible returns
DEFAULTS = {
    "void": None,
    "int": "1", "boolean": "true", "float": "0.0f", "double": "0.0d",
    "long": "1L", "short": "(short) 1", "byte": "(byte) 1", "char": "(char) 1",
    "java.nio.Buffer": "null", "java.nio.ByteBuffer": "null",
    "java.lang.String": "null",
}

written = 0
for cls in TARGETS:
    pkg, simple = cls.rsplit(".", 1)
    try:
        consts, methods, ctors = parse(cls)
    except Exception as e:
        print(f"  skip {cls}: {e}")
        continue
    d = os.path.join(STUB, *pkg.split("."))
    os.makedirs(d, exist_ok=True)

    is_exception = simple.endswith("Exception")
    body = [f"package {pkg};", ""]
    if is_exception:
        body.append(f"public class {simple} extends RuntimeException {{")
        body.append("    public %s() { super(); }" % simple)
        body.append("    public %s(String m) { super(m); }" % simple)
        body.append("    public %s(String m, Throwable c) { super(m, c); }" % simple)
        body.append("}")
    else:
        body.append(f"public final class {simple} {{")
        for name in consts:
            body.append(f"    public static final int {name} = 0;")
        # public constructors must keep their exact descriptors: Minecraft.<clinit>
        # calls `new DisplayMode(854, 480)` and a missing ctor is a hard boot failure.
        for args in ctors:
            named = ", ".join(f"{a} a{i}" for i, a in enumerate(args))
            body.append(f"    public {simple}({named}) {{ }}")
        for ret, name, args in methods:
            if ret == "void":
                named = ", ".join(f"{a} a{i}" for i, a in enumerate(args))
                body.append(f"    public static void {name}({named}) {{ }}")
                continue
            named = ", ".join(f"{a} a{i}" for i, a in enumerate(args))
            if name in RETURN_NONZERO:
                if ret in ("int", "boolean", "long", "short", "byte"):
                    body.append(f"    public static {ret} {name}({named}) {{ return 1; }}")
                elif ret == "float":
                    body.append(f"    public static {ret} {name}({named}) {{ return 1.0f; }}")
                elif ret == "double":
                    body.append(f"    public static {ret} {name}({named}) {{ return 1.0d; }}")
                else:
                    body.append(f"    public static {ret} {name}({named}) {{ return null; }}")
                continue
            if name.startswith("glGet") and ret in ("float", "int", "boolean"):
                zero = "false" if ret == "boolean" else f"({ret}) 0"
                body.append(f"    public static {ret} {name}({named}) {{ return {zero}; }}")
                continue
            # Object already declares toString/equals/hashCode; re-emitting them
            # breaks the override rules, so keep Object's versions.
            if name in ("toString", "equals", "hashCode", "clone", "finalize"):
                continue
            if ret in DEFAULTS and DEFAULTS[ret] is not None:
                body.append(f"    public static {ret} {name}({named}) {{ return {DEFAULTS[ret]}; }}")
            elif ret == "void":
                body.append(f"    public static void {name}({named}) {{ }}")
            else:
                body.append(f"    public static {ret} {name}({named}) {{ return null; }}")
        body.append("}")
    open(os.path.join(d, simple + ".java"), "w").write("\n".join(body) + "\n")
    written += 1

print(f"wrote {written} signature-accurate LWJGL stubs to {STUB}")