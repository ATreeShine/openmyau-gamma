#!/usr/bin/env python3
"""
Runtime verification of the imported modules.

Full in-game boot is not reproducible here (Minecraft's registry needs a live FML
environment and a GL context), so this test goes as deep as is possible without
one. It really loads every class out of the built jar and reflects over it:

  * class loads and resolves with the jar's own dependencies;
  * it extends Myau's Module, so it lands in Myau's GUI/config/event system;
  * its @EventTarget handlers take a Myau Event subclass, so Myau's EventManager
    (which dispatches on exact class) will actually find them;
  * its Property fields are Myau Property subclasses, so Myau's ClickGui/config
    will see them;
  * its display name carries the openskid- prefix;
  * it instantiates, where that does not require a game instance.
"""
import glob, json, os, re, subprocess, sys, tempfile, zipfile

JAR = sys.argv[1] if len(sys.argv) > 1 else \
    "/root/work/MyauMerged/build/intermediates/MyauFix-1.6-non-obfuscated-with-deps.jar"
SHIM_JAR = "/tmp/opencode/myau-build/package/MyauFix-1.6.jar"
LOOM = ("/root/.gradle/caches/essential-loom/1.8.9/"
        "de.oceanlabs.mcp.mcp_stable.1_8_9.22-1.8.9-forge-1.8.9-11.15.1.2318-1.8.9")
MC = os.path.join(LOOM, "minecraft-mapped.jar")
FORGE = os.path.join(LOOM, "forge", "forge-mapped.jar")
GLSTUB = "/tmp/myau-glstub-classes"

WORK = tempfile.mkdtemp(prefix="myau-rt-")
fails = []


def check(cond, msg):
    print(("  OK   " if cond else "  FAIL ") + msg)
    if not cond:
        fails.append(msg)


for p in (JAR, MC, FORGE, GLSTUB):
    if not os.path.exists(p):
        sys.exit("missing required input: " + p)

# registered modules, straight from the source of truth
src = open("/root/work/MyauMerged/src/main/java/myau/Myau.java", encoding="utf-8").read()
REGISTERED = re.findall(r"moduleManager\.modules\.put\(openskid\.module\.modules\.(\w+)\.class", src)

HARNESS = r'''
import java.io.*;
import java.lang.annotation.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

public class Rt {
    static int fails = 0;
    static void ok(boolean c, String m) {
        System.out.println((c ? "  OK   " : "  FAIL ") + m);
        if (!c) failures: fails++;
    }

    public static void main(String[] args) throws Exception {
        Class<?> moduleBase = Class.forName("myau.module.Module");
        Class<?> propBase = Class.forName("myau.property.Property");
        Class<?> eventBase = Class.forName("myau.event.events.Event");
        Class<?> targetAnn = Class.forName("myau.event.EventTarget");
        System.out.println("  OK   Myau infrastructure classes loaded");

        // Myau's Module.toggle() dereferences Myau.moduleManager (for the HUD toggle sound),
        // so a real ModuleManager has to exist before anything is toggled. Constructing the
        // full client is impossible headlessly, so stand one up directly.
        Class<?> myauCls = Class.forName("myau.Myau");
        Field mmField = myauCls.getField("moduleManager");
        Field pmField = myauCls.getField("propertyManager");
        Object mm = Class.forName("myau.module.ModuleManager").getDeclaredConstructor().newInstance();
        mmField.set(null, mm);
        pmField.set(null, Class.forName("myau.property.PropertyManager").getDeclaredConstructor().newInstance());
        ok(true, "ModuleManager/PropertyManager stood up for toggling");
        // Myau's own Module.toggle() looks up HUD unconditionally for the toggle sound,
        // so register Myau's HUD too - otherwise every toggle NPEs on the null.
        // Many modules dereference `Minecraft.getMinecraft()`, which is null headlessly.
        // Allocate an uninitialised Minecraft instance and publish it in the private
        // static field so those code paths run exactly as they would in-game (with
        // thePlayer/theWorld null, which those modules already guard against).
        Class<?> mcCls = Class.forName("net.minecraft.client.Minecraft");
        sun.misc.Unsafe unsafe = null;
        try {
            Field uf = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            uf.setAccessible(true);
            unsafe = (sun.misc.Unsafe) uf.get(null);
        } catch (Throwable t) {
            ok(false, "Unsafe unavailable, cannot fake Minecraft: " + t);
            System.exit(1);
        }
        Object mcInst = unsafe.allocateInstance(mcCls);
        try {
            Class<?> gsCls = Class.forName("net.minecraft.client.settings.GameSettings");
            Constructor<?> gsc = gsCls.getDeclaredConstructors()[0];
            Object[] ga = new Object[gsc.getParameterTypes().length];
            for (int i = 0; i < ga.length; i++) {
                Class<?> pt = gsc.getParameterTypes()[i];
                if (pt == java.io.File.class) ga[i] = new java.io.File("dummy-gameoptions.txt");
                else if (pt.isPrimitive()) ga[i] = Integer.valueOf(0);
                else ga[i] = null;
            }
            gsc.setAccessible(true);
            Object gs = gsc.newInstance(ga);
            mcCls.getField("gameSettings").set(mcInst, gs);
            ok(true, "GameSettings installed on the fake Minecraft instance");
        } catch (Throwable t) {
            System.out.println("  note   could not install GameSettings: " + t);
        }
        Field theMinecraft = mcCls.getDeclaredField("theMinecraft");
        theMinecraft.setAccessible(true);
        theMinecraft.set(null, mcInst);

        Object hud = Class.forName("myau.module.modules.HUD").getDeclaredConstructor().newInstance();
        java.util.Map mods = (java.util.Map) mm.getClass().getField("modules").get(mm);
        mods.put(hud.getClass(), hud);

        List<String> names = new ArrayList<String>();
        BufferedReader r = new BufferedReader(new FileReader(args[0]));
        String line;
        while ((line = r.readLine()) != null) if (!line.trim().isEmpty()) names.add(line.trim());
        r.close();

        int loaded = 0, notModule = 0, badHandler = 0, badProp = 0, noHandlers = 0;
        int handlers = 0, props = 0, ctorFail = 0, ctorOk = 0, needsGame = 0;
        List<String> handlerProblems = new ArrayList<String>();
        List<String> ctorProblems = new ArrayList<String>();

        // Classify failures by CAUSE rather than by a hardcoded module list: most of
        // them are "this needs a live game", not "this port is broken".
        Map<String, Integer> reasons = new LinkedHashMap<String, Integer>();
        List<String> real = new ArrayList<String>();

        for (String simple : names) {
            String fqn = "openskid.module.modules." + simple;
            Class<?> c;
            try {
                // initialize=false: resolve the class without running Minecraft statics
                c = Class.forName(fqn, false, Rt.class.getClassLoader());
            } catch (Throwable t) {
                ok(false, "load " + fqn + ": " + t);
                continue;
            }
            loaded++;
            if (!moduleBase.isAssignableFrom(c) || Modifier.isAbstract(c.getModifiers())) { notModule++; continue; }

            int localHandlers = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (m.getAnnotation((Class) targetAnn) == null) continue;
                localHandlers++; handlers++;
                Class<?> p = m.getParameterTypes()[0];
                if (!eventBase.isAssignableFrom(p)) {
                    badHandler++;
                    handlerProblems.add(simple + "#" + m.getName() + " -> " + p.getName());
                }
            }
            if (localHandlers == 0) noHandlers++;

            int localProps = 0;
            for (Field f : c.getDeclaredFields()) {
                if (!propBase.isAssignableFrom(f.getType())) continue;
                localProps++; props++;
            }

            try {
                Constructor<?> ctor = c.getDeclaredConstructor();
                ctor.setAccessible(true);
                Object inst = ctor.newInstance();
                if (inst == null) throw new IllegalStateException("null instance");
                if (!moduleBase.isInstance(inst)) throw new IllegalStateException("not a Module");
                Method tog = c.getMethod("toggle");
                tog.invoke(inst);
                tog.invoke(inst);
                // count only here: a module whose toggle threw must not also count as ok
                ctorOk++;
            } catch (Throwable t) {
                Throwable root = t;
                while (root.getCause() != null && root.getCause() != root) root = root.getCause();
                StringBuilder trace = new StringBuilder();
                StackTraceElement[] st = root.getStackTrace();
                for (int i = 0; i < Math.min(6, st.length); i++) trace.append(" | ").append(st[i]);

                String msg = String.valueOf(root);
                String reason = null;
                // 1. mixins are not applied in this harness, so Minecraft does not
                //    implement the IAccessor* interfaces the modules cast to.
                if (root instanceof ClassCastException && trace.indexOf("IAccessor") >= 0) {
                    reason = "casts Minecraft to a mixin accessor (mixins not applied here)";
                // 2. Minecraft's block/item registries need a live game.
                } else if (trace.indexOf("net/minecraft/init") >= 0
                        || msg.contains("before Bootstrap")
                        || trace.indexOf("InitializationException") >= 0
                        || trace.indexOf("GuiMainMenu") >= 0) {
                    reason = "needs Minecraft's live block/item registry";
                // 4. constructors that touch the render engine or the display settings.
                } else if (trace.indexOf("loadCapes") >= 0
                        || trace.indexOf("ScaledResolution") >= 0
                        || trace.indexOf("renderEngine") >= 0) {
                    reason = "constructor touches the render engine / display settings";
                // 3. onEnabled/onDisabled touching mc.thePlayer / theWorld, which are
                //    null because no world is loaded.
                } else if (trace.indexOf(".onEnabled(") >= 0 || trace.indexOf(".onDisabled(") >= 0
                        || trace.indexOf(".reset") >= 0) {
                    reason = "onEnabled/onDisabled touches the player or world (none loaded)";
                }

                if (reason != null) {
                    needsGame++;
                    Integer n = reasons.get(reason);
                    reasons.put(reason, n == null ? 1 : n + 1);
                } else {
                    ctorFail++;
                    real.add(simple + ": " + root + trace);
                }
            }
        }

        ok(loaded == names.size(), "all " + names.size() + " registered module classes load (got " + loaded + ")");
        ok(notModule == 0, "all extend myau.module.Module" + (notModule > 0 ? " (" + notModule + " bad)" : ""));
        ok(badHandler == 0, "all " + handlers + " @EventTarget handlers take a Myau Event"
                + (badHandler > 0 ? " BAD: " + handlerProblems : ""));
        ok(props > 500, "modules expose " + props + " Myau Property fields");
        System.out.println("  note   " + noHandlers + " modules have no @EventTarget handler (toggle-only modules)");
        for (String cp : real) System.out.println("        REAL FAILURE: " + cp);
        ok(ctorFail == 0, "instantiated + toggled " + ctorOk + "/" + names.size()
                + " modules cleanly (environment-limited: " + needsGame + ")");
        for (Map.Entry<String, Integer> e : reasons.entrySet()) {
            System.out.println("        env-limited x" + e.getValue() + ": " + e.getKey());
        }
        if (needsGame > 0) {
            System.out.println("  note   " + needsGame + " modules need a live Minecraft registry to construct (Blocks/Items)");
        }

        System.out.println(fails == 0 ? "\nRUNTIME OK" : "\nRUNTIME FAILURES: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
'''
# (fix the deliberate label typo in a clean copy)
HARNESS = HARNESS.replace("if (!c) failures: fails++;", "if (!c) fails++;")

stub_dir = os.path.join(WORK, "_stub")
os.makedirs(stub_dir)
open(os.path.join(stub_dir, "Rt.java"), "w").write(HARNESS)
list_file = os.path.join(WORK, "modules.txt")
open(list_file, "w").write("\n".join(REGISTERED))

WANT = ("org.lwjgl.lwjgl", "com.google.guava", "org.apache.logging.log4j",
        "net.java.dev.jna", "net.sf.jopt-simple", "com.google.code.gson",
        "io.netty", "commons-io", "commons-codec", "org.apache.httpcomponents",
        "org.ow2.asm", "com.paulscode", "org.apache.commons", "it.unimi.dsi",
        "org.jline", "net.java.jinput", "net.minecraft", "com.google.jimfs",
        "com.ibm.icu", "com.mojang", "net.java", "jline", "lzma", "java3d",
        "oshi-project", "tv.twitch", "net.sf.trove4j")
GRADLE_MODS = "/root/.gradle/caches/modules-2/files-2.1"
deps = []
for g in os.listdir(GRADLE_MODS):
    if not any(g == w or g.startswith(w + ".") for w in WANT):
        continue
    for j in glob.glob(os.path.join(GRADLE_MODS, g, "**", "*.jar"), recursive=True):
        if j.endswith(("-sources.jar", "-javadoc.jar")):
            continue
        deps.append(j)
# real LWJGL would dlopen natives; the signature-accurate stubs go first
deps = [GLSTUB] + [d for d in sorted(set(deps)) if "/org.lwjgl.lwjgl/" not in d]

CP = ":".join([JAR, MC, FORGE] + deps)
javac = "/usr/lib/jvm/java-8-openjdk-amd64/bin/javac"
java = "/usr/lib/jvm/java-8-openjdk-amd64/bin/java"

r = subprocess.run([javac, "-nowarn", "-proc:none", "-cp", CP, "-d", stub_dir,
                    os.path.join(stub_dir, "Rt.java")], capture_output=True, text=True)
if r.returncode != 0:
    print("harness compile failed:\n" + r.stderr[:2500])
    sys.exit(2)

print(f"jar  : {JAR}")
print(f"mods : {len(REGISTERED)} registered\n")
r = subprocess.run([java, "-cp", ":".join([stub_dir] + CP.split(":")), "Rt", list_file],
                   capture_output=True, text=True, timeout=600)
print(r.stdout)
if r.returncode != 0 and r.stderr.strip():
    print("--- stderr (tail) ---")
    print("\n".join(r.stderr.strip().split("\n")[-20:]))
sys.exit(r.returncode)