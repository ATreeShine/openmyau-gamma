#!/usr/bin/env python3
"""
Batch 2: import the REST of OpenSkid's modules.

Batch 1 deliberately skipped the 76 modules whose names collide with Myau's own
(AutoClicker, KillAura, Scaffold, HUD, ...). The user now wants every OpenSkid
module present, prefixed `openskid-`, so the colliding ones are imported too and
each client keeps its own copy.

Difference from batch 1: the OVERLAP alias rewrite must NOT run here. These files
live in `openskid.module.modules` alongside their now-vendored siblings, so a bare
`Scaffold` / `HUD` / `KillAura` correctly resolves to the OpenSkid original.
"""
import os, re, shutil, sys

SRC = "/root/OpenSkid/src/main/java"
DST = "/root/work/MyauMerged/src/main/java"
OSK = os.path.join(SRC, "openskid")
DSTOSK = os.path.join(DST, "openskid")

SHARED_PROPS = ["BooleanProperty", "ColorProperty", "FloatProperty", "IntProperty",
                "ModeProperty", "PercentProperty", "TextProperty"]
NEW_PROPS = ["DragProperty", "ItemListProperty", "LongProperty"]
MYAU_MIXINS = {f[:-5] for f in os.listdir(os.path.join(DST, "myau/mixin")) if f.endswith(".java")}
OSK_MIXINS = {f[:-5] for f in os.listdir(os.path.join(OSK, "mixin"))
              if f.endswith(".java") and os.path.isfile(os.path.join(OSK, "mixin", f))}
SHARED_MIXINS = sorted(MYAU_MIXINS & OSK_MIXINS)
OSK_ONLY_MIXINS = sorted(OSK_MIXINS - MYAU_MIXINS)
MYAU_EVENTS = {f[:-5] for f in os.listdir(os.path.join(DST, "myau/events")) if f.endswith(".java")}

# already vendored
have = {f[:-5] for f in os.listdir(os.path.join(DSTOSK, "module/modules")) if f.endswith(".java")}
# everything OpenSkid ships
want = {f[:-5] for f in os.listdir(os.path.join(OSK, "module/modules")) if f.endswith(".java")}
missing = sorted(want - have)

# ScriptModule is only an adapter for the vendored keystrokesmod/RSL script engine,
# which is a separate obfuscated project and not part of OpenSkid's own source.
SKIP = {"ScriptModule"}

todo = [m for m in missing if m not in SKIP]
helpers = [m for m in todo if not re.search(
    r"^public (?:final )?class " + re.escape(m) + r"\b[^;{]*?extends Module\b",
    open(os.path.join(OSK, "module/modules", m + ".java"), encoding="utf-8").read(), re.M | re.S)]
modules = [m for m in todo if m not in helpers]
print(f"to import: {len(modules)} modules + {len(helpers)} helpers (skipping {sorted(SKIP)})")


def copy(name):
    s = os.path.join(OSK, "module/modules", name + ".java")
    d = os.path.join(DSTOSK, "module/modules", name + ".java")
    os.makedirs(os.path.dirname(d), exist_ok=True)
    shutil.copy2(s, d)


def rewrite(path, prefix_name=False):
    src = open(path, encoding="utf-8", errors="replace").read()
    orig = src
    # NO overlap aliasing here - siblings are vendored now.
    src = re.sub(r"\bopenskid\.module\.ModuleManager\b", "myau.module.ModuleManager", src)
    src = re.sub(r"\bopenskid\.module\.Module\b", "myau.module.Module", src)
    src = re.sub(r"\bopenskid\.property\.properties\.(\*|\w+)",
                 lambda m: "myau.property.properties." + m.group(1), src)
    for p in NEW_PROPS:
        src = src.replace("myau.property.properties." + p, "openskid.property.properties." + p)
    src = re.sub(r"\bopenskid\.property\.Property\b", "myau.property.Property", src)
    src = re.sub(r"\bopenskid\.property\.PropertyManager\b", "myau.property.PropertyManager", src)
    src = re.sub(r"\bopenskid\.event\.events\.callables\.", "myau.event.events.callables.", src)
    src = re.sub(r"\bopenskid\.event\.events\.", "myau.event.events.", src)
    src = re.sub(r"\bopenskid\.event\.types\.", "myau.event.types.", src)
    src = re.sub(r"\bopenskid\.event\.", "myau.event.", src)
    src = re.sub(r"\bopenskid\.events\.(\*|\w+)", lambda m: "myau.events." + m.group(1), src)
    src = re.sub(r"\bopenskid\.enums\.", "myau.enums.", src)
    src = re.sub(r"\bopenskid\.config\.", "myau.config.", src)
    for m in SHARED_MIXINS:
        src = re.sub(r"\bopenskid\.mixin\." + m + r"\b", "myau.mixin." + m, src)
    for m in OSK_ONLY_MIXINS:
        src = re.sub(r"\bopenskid\.mixin\." + m + r"\b", "myau.mixin.Os" + m, src)
    src = re.sub(r"\bimport\s+openskid\.OpenSkid\s*;", "import myau.Myau;", src)
    src = re.sub(r"\bopenskid\.OpenSkid\b", "myau.Myau", src)
    src = re.sub(r"\bOpenSkid\.", "Myau.", src)
    if prefix_name and '"openskid-' not in src:
        src = re.sub(r'(\n\s*super\()"([^"]+)"',
                     lambda mo: mo.group(1) + '"openskid-' + mo.group(2) + '"', src, count=1)
    if src != orig:
        open(path, "w", encoding="utf-8").write(src)


for m in todo:
    copy(m)
for m in todo:
    rewrite(os.path.join(DSTOSK, "module/modules", m + ".java"),
            prefix_name=(m in modules))
print("batch 2 copied + rewritten")

# keep ScriptModule's absence explicit rather than silently gone
print("skipped:", sorted(SKIP), "(needs the RSL/keystrokesmod script engine)")
