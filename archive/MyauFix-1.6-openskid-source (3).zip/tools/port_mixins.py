#!/usr/bin/env python3
"""Stage 2b: rewrite the vendored Os* mixins (they live in myau/mixin, not openskid/mixin)."""
import os, re, sys
sys.path.insert(0, "/root/work")
from port import rewrite_file, OSK_ONLY_MIXINS, DST

n = 0
for m in OSK_ONLY_MIXINS:
    p = os.path.join(DST, "myau/mixin", "Os" + m + ".java")
    if not os.path.exists(p):
        print("missing", p)
        continue
    extra = (
        (r"^package\s+openskid\.mixin\s*;", "package myau.mixin;"),
        (r"\b" + m + r"\b", "Os" + m),
    )
    if rewrite_file(p, extra):
        n += 1
print(f"rewrote {n}/{len(OSK_ONLY_MIXINS)} vendored mixins")