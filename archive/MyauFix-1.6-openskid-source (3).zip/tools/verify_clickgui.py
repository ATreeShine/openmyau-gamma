#!/usr/bin/env python3
"""
Regression test for the ClickGui module-category fix.

The ClickGui used to throw from its constructor when any registered module was
missing from its hardcoded lists, which bricked the whole gui. This checks, by
loading the real compiled classes:

  1. no module is left uncategorised (importedCategory returns a bucket),
  2. every registered module is covered by exactly one column,
  3. ClickGui's constructor no longer contains a throw-on-unregistered path.
"""
import glob, os, re, subprocess, sys, tempfile, zipfile

JAR = sys.argv[1] if len(sys.argv) > 1 else \
    "/root/work/MyauMerged/build/intermediates/MyauFix-1.6-non-obfuscated-with-deps.jar"
LOOM = ("/root/.gradle/caches/essential-loom/1.8.9/"
        "de.oceanlabs.mcp.mcp_stable.1_8_9.22-1.8.9-forge-1.8.9-11.15.1.2318-1.8.9")
MC = os.path.join(LOOM, "minecraft-mapped.jar")
FORGE = os.path.join(LOOM, "forge", "forge-mapped.jar")
GLSTUB = "/tmp/myau-glstub-classes"
SRC = "/root/work/MyauMerged/src/main/java"

for p in (JAR, MC, FORGE, GLSTUB):
    if not os.path.exists(p):
        sys.exit("missing input: " + p)

WORK = tempfile.mkdtemp(prefix="myau-cat-")

# ---------- static side ------------------------------------------------------
myau_src = open(os.path.join(SRC, "myau/Myau.java"), encoding="utf-8").read()
registered = set(re.findall(r"moduleManager\.modules\.put\(([\w.]+)\.class", myau_src))
imported = {c for c in registered if c.startswith("openskid.module.modules.")}
print(f"registered modules: {len(registered)}  (imported: {len(imported)})")

gui_src = open(os.path.join(SRC, "myau/ui/ClickGui.java"), encoding="utf-8").read()

# the crash signature we are removing
fails = []
if "is unregistered to click gui" in gui_src:
    fails.append("ClickGui still throws on an unregistered module")
else:
    print("  OK   throw-on-unregistered removed from ClickGui")

# the map must cover every imported module's simple name
table = {}
for m in re.finditer(r'IMPORTED_CATEGORY\.put\(name, "(\w+)"\);', gui_src):
    pass
# parse: for (String name : new String[] { ... }) { IMPORTED_CATEGORY.put(name, "BUCKET"); }
for block in re.finditer(r"for \(String name : new String\[\] \{(.*?)\}\)", gui_src, re.S):
    body = block.group(1)
    names = re.findall(r'"([^"]+)"', body)
    tail = gui_src[block.end():block.end() + 200]
    bucket = re.search(r'IMPORTED_CATEGORY\.put\(name, "(\w+)"\)', tail)
    if not bucket:
        continue
    for n in names:
        table[n] = bucket.group(1)

print(f"  category table entries: {len(table)}")
by_bucket = {}
for n, b in table.items():
    by_bucket.setdefault(b, []).append(n)
for b in sorted(by_bucket):
    print(f"      {b:9s} {len(by_bucket[b])}")

missing = sorted(c.split(".")[-1] for c in imported if c.split(".")[-1] not in table)
if missing:
    fails.append(f"{len(missing)} imported modules have no category: {missing}")
else:
    print(f"  OK   every one of the {len(imported)} imported modules has a category")

if len(table) != len(set(table)):
    fails.append("duplicate entries in the category table")

# The imported table intentionally shares simple names with Myau's own modules
# (openskid-KillAura is the twin of KillAura). What must hold is that the gui can
# tell the two apart, i.e. every DISPLAY name is unique across the whole client -
# that is the key used by the gui rows, the config file and the chat commands.
# Read the REAL display names from the sources: the gui rows, the config file and the
# chat commands are all keyed on module.getName(), so that is what must be unique
# across the WHOLE client (Myau's 135 + the 205 imported).
disp = {}
for pkg, src_dir in (("myau", "myau/module/modules"),
                     ("openskid", "openskid/module/modules")):
    d = os.path.join(SRC, src_dir)
    for f in os.listdir(d):
        if not f.endswith(".java"):
            continue
        text = open(os.path.join(d, f), encoding="utf-8").read()
        m = re.search(r'super\("([^"]+)"', text)
        if m:
            # key by package + class: the 76 imported twins share a simple name with a
            # Myau module, and a plain simple-name key would silently drop one of each.
            disp[(pkg, f[:-5])] = (pkg, m.group(1))

by_name = {}
for key, (pkg, name) in disp.items():
    by_name.setdefault(name, []).append(f"{pkg}.{key[1]}")
dupes = {n: v for n, v in by_name.items() if len(v) > 1}
if dupes:
    fails.append(f"{len(dupes)} DISPLAY names are shared by more than one module "
                 f"(gui rows / config keys would collide): {dupes}")
else:
    print(f"  OK   all {len(disp)} modules have a unique display name "
          f"({len(by_name)} distinct)")

# and the code must only consult the table for modules NOT already hardcoded
if "if (registered.contains(module))" not in gui_src:
    fails.append("importedCategory may be consulted for already-placed Myau modules")

# ---------- runtime side -----------------------------------------------------
HARNESS = r'''
import java.io.*;
import java.lang.reflect.*;
import java.util.*;

public class Cat {
    static sun.misc.Unsafe UNSAFE;

    static {
        try {
            java.lang.reflect.Field f = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            UNSAFE = (sun.misc.Unsafe) f.get(null);
        } catch (Throwable t) {
            throw new IllegalStateException("Unsafe unavailable", t);
        }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader r = new BufferedReader(new FileReader(args[0]));
        String line;
        int total = 0, nulls = 0;
        StringBuilder bad = new StringBuilder();
        while ((line = r.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            Class<?> c = Class.forName(line.trim(), false, Cat.class.getClassLoader());
            Method m = Class.forName("myau.ui.ClickGui")
                    .getDeclaredMethod("importedCategory", Class.forName("myau.module.Module"));
            m.setAccessible(true);
            // Unsafe.allocateInstance: the method only reads getClass().getSimpleName(),
            // so there is no reason to run module constructors here (some of them need a
            // live render engine / Minecraft registry, which this harness has no).
            Object inst = UNSAFE.allocateInstance(c);
            String bucket = (String) m.invoke(null, inst);
            total++;
            if (bucket == null) { nulls++; bad.append(line.trim()).append(" "); }
        }
        r.close();
        System.out.println("  OK   importedCategory() resolved " + (total - nulls) + "/" + total
                + " modules");
        if (nulls > 0) {
            System.out.println("  FAIL unresolved: " + bad);
            System.exit(1);
        }
    }
}
'''
stub = os.path.join(WORK, "Cat.java")
open(stub, "w").write(HARNESS)
listf = os.path.join(WORK, "mods.txt")
open(listf, "w").write("\n".join(sorted(imported)))

WANT = ("org.lwjgl.lwjgl", "com.google.guava", "org.apache.logging.log4j",
        "net.java.dev.jna", "net.sf.jopt-simple", "com.google.code.gson",
        "io.netty", "commons-io", "commons-codec", "org.apache.httpcomponents",
        "org.ow2.asm", "com.paulscode", "org.apache.commons", "it.unimi.dsi",
        "org.jline", "net.java.jinput", "net.minecraft", "com.ibm.icu", "com.mojang")
deps = []
for g in os.listdir("/root/.gradle/caches/modules-2/files-2.1"):
    if any(g == w or g.startswith(w + ".") for w in WANT):
        deps += [j for j in glob.glob(f"/root/.gradle/caches/modules-2/files-2.1/{g}/**/*.jar",
                                      recursive=True)
                 if not j.endswith(("-sources.jar", "-javadoc.jar"))]
deps = [GLSTUB] + [d for d in sorted(set(deps)) if "/org.lwjgl.lwjgl/" not in d]
CP = ":".join([JAR, MC, FORGE] + deps)
javac = "/usr/lib/jvm/java-8-openjdk-amd64/bin/javac"
java = "/usr/lib/jvm/java-8-openjdk-amd64/bin/java"

r = subprocess.run([javac, "-nowarn", "-proc:none", "-cp", CP, "-d", WORK, stub],
                   capture_output=True, text=True)
if r.returncode != 0:
    print("harness compile failed:\n" + r.stderr[:1500])
    sys.exit(2)

r = subprocess.run([java, "-cp", ":".join([WORK] + CP.split(":")), "Cat", listf],
                   capture_output=True, text=True, timeout=300)
print(r.stdout.strip())
if r.returncode != 0:
    fails.append("runtime importCategory() check failed")
    if r.stderr.strip():
        print("\n".join(r.stderr.strip().split("\n")[-6:]))

print("=" * 60)
if fails:
    print("FAILED:")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("CLICKGUI CATEGORISATION OK")