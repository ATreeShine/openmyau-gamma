#!/usr/bin/env python3
"""Static verification of the produced jar: class inventory + mixin wiring."""
import zipfile, re, sys, collections

JAR = sys.argv[1] if len(sys.argv) > 1 else "/root/work/MyauMerged/build/libs/MyauFix-1.6.jar"
z = zipfile.ZipFile(JAR)
names = z.namelist()
classes = [n[:-6].replace("/", ".") for n in names if n.endswith(".class")]

print(f"jar: {JAR}")
print(f"entries: {len(names)}   classes: {len(classes)}")

def count(pkg):
    return len([c for c in classes if c.startswith(pkg + ".")])

print("\n-- package inventory --")
for p in ["myau.module.modules", "openskid.module.modules", "openskid.util",
          "openskid.font", "myau.mixin", "myau.events", "openskid.events",
          "myau.property.properties", "openskid.property.properties",
          "myau.management", "openskid.management", "me.ksyz"]:
    print(f"  {p:38s} {count(p)}")

# registered modules
src = open("/root/work/MyauMerged/src/main/java/myau/Myau.java", encoding="utf-8").read()
reg = re.findall(r"moduleManager\.modules\.put\(openskid\.module\.modules\.(\w+)\.class", src)
print(f"\n-- registered openskid modules in Myau.java: {len(reg)}")

missing_cls = [c for c in reg if "openskid.module.modules." + c not in classes]
print(f"registered but NOT in jar: {missing_cls if missing_cls else 'none'}")

# every registered module class file present AND extends Myau's Module
missing_mod = [c for c in reg if f"openskid/module/modules/{c}.class" not in names]
print(f"module class files missing: {missing_mod if missing_mod else 'none'}")

# mixin config: Os* mixins must be discoverable by the auto-scanning plugin
mixins = [c for c in classes if c.startswith("myau.mixin.") and "$" not in c]
os_mixins = sorted(c.split(".")[-1] for c in mixins if c.split(".")[-1].startswith("Os"))
print(f"\n-- vendored Os* mixins ({len(os_mixins)}) --")
for m in os_mixins:
    print("   ", m)
print(f"total myau.mixin classes: {len(mixins)}")

# display names
mod_names = []
for c in reg:
    try:
        data = z.read(f"openskid/module/modules/{c}.class")
    except KeyError:
        continue
    for m in re.finditer(rb"openskid-([A-Za-z0-9_]+)", data):
        mod_names.append(m.group(1).decode())
        break
dupes = [k for k, v in collections.Counter(mod_names).items() if v > 1]
print(f"\n-- openskid- display names found: {len(mod_names)}")
print(f"duplicates: {dupes if dupes else 'none'}")

# collisions against Myau's own modules
myau_mods = sorted(f[:-6].split("/")[-1] for f in names
                   if f.startswith("myau/module/modules/") and f.endswith(".class")
                   and "$" not in f)
print(f"myau own module classes: {len(myau_mods)}")
bad = [c for c in reg if c in myau_mods]
print(f"COLLISIONS with existing Myau modules: {bad if bad else 'none'}")