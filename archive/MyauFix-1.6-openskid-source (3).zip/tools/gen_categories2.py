#!/usr/bin/env python3
"""
Rebuild ClickGui's IMPORTED_CATEGORY table to cover ALL imported OpenSkid modules.

Batch 2 added the OpenSkid twins of Myau's own modules (openskid-KillAura next to
KillAura, and so on). The obvious place for each is the column its Myau twin is
already in, so that mapping is derived from ClickGui's own hardcoded lists rather
than guessed. Anything with no twin falls back to a name-based guess, then Misc.
"""
import os, re, sys, zipfile

SRC = "/root/work/MyauMerged/src/main/java"
GUI = os.path.join(SRC, "myau/ui/ClickGui.java")
MYAU = os.path.join(SRC, "myau/Myau.java")
JAR = "/root/work/MyauMerged/build/libs/MyauFix-1.6.jar"

gui = open(GUI, encoding="utf-8").read()

# ---- where does each MYAU module currently sit? ---------------------------
bucket_of = {}
for m in re.finditer(r"List<Module> (\w+Modules) = new ArrayList<>\(\);(.*?)\n\n", gui, re.S):
    var, body = m.group(1), m.group(2)
    for cls in re.findall(r"getModule\((?:myau\.module\.modules\.)?([\w.]+)\.class\)", body):
        bucket_of[cls.split(".")[-1]] = var.replace("Modules", "").upper()
print("myau modules placed by the existing lists:", len(bucket_of))

# ---- which imported modules are still unmapped? ---------------------------
table = {}
for block in re.finditer(r"for \(String name : new String\[\] \{(.*?)\}\)", gui, re.S):
    names = re.findall(r'"([^"]+)"', block.group(1))
    tail = gui[block.end():block.end() + 200]
    b = re.search(r'IMPORTED_CATEGORY\.put\(name, "(\w+)"\)', tail)
    if b:
        for n in names:
            table[n] = b.group(1)
print("existing table entries:", len(table))

# ---- display name for every registered imported module --------------------
myau_src = open(MYAU, encoding="utf-8").read()
registered = re.findall(r"moduleManager\.modules\.put\(openskid\.module\.modules\.(\w+)\.class", myau_src)
if not os.path.isfile(JAR):
    sys.exit("build the jar first: " + JAR)
z = zipfile.ZipFile(JAR)
simple_to_disp = {}
for c in registered:
    data = z.read(f"openskid/module/modules/{c}.class")
    m = re.search(rb'openskid-([A-Za-z0-9_]+)', data)
    simple_to_disp[c] = m.group(1).decode()

missing = sorted(c for c in simple_to_disp if c not in table)
print("unmapped imported modules:", len(missing))

# ---- assign: Myau twin first, then a small keyword fallback ---------------
KEYWORDS = [
    ("COMBAT", ["aura", "click", "crit", "hitbox", "reach", "kill", "combat",
                "damage", "armor", "bed", "gapple", "soup", "pot", "rod",
                "refill", "target", "throw", "piercing", "flick", "speedbuild"]),
    ("MOVEMENT", ["fly", "sprint", "step", "scaffold", "walk", "climb", "phase",
                  "vclip", "parkour", "ladder", "water", "safe", "bridge",
                  "nojump", "nostop", "noslow", "jump", "spider", "tower", "legitreach"]),
    ("RENDER", ["esp", "hud", "radar", "overlay", "tag", "watermark", "block",
                "render", "chams", "anim", "trajector", "fullbright", "physics",
                "keystroke", "fps", "island", "counter", "warning", "effect"]),
]

assigned, unresolved = {}, []
for c in missing:
    low = c.lower()
    twin = bucket_of.get(c)
    if twin:
        assigned[c] = twin
        continue
    hit = None
    for b, words in KEYWORDS:
        if any(w in low for w in words):
            hit = b
            break
    if hit:
        assigned[c] = hit
    else:
        assigned[c] = "MISC"
        unresolved.append(c)

print(f"assigned {len(assigned)}  (by twin: {sum(1 for c in missing if c in bucket_of)},"
      f" by keyword: {len(assigned) - sum(1 for c in missing if c in bucket_of) - len(unresolved)},"
      f" fallback Misc: {len(unresolved)})")
if unresolved:
    print("  fell back to Misc:", " ".join(unresolved))

table.update(assigned)

# ---- rewrite the whole table ---------------------------------------------
ORDER = ["COMBAT", "MOVEMENT", "RENDER", "PLAYER", "MISC"]
BUCKETS = {b: sorted(n for n, v in table.items() if v == b) for b in ORDER}
for b in ORDER:
    print(f"  {b:9s} {len(BUCKETS[b])}")
assert sum(len(v) for v in BUCKETS.values()) == len(simple_to_disp), "coverage mismatch"
assert all(len(v) == len(set(v)) for v in BUCKETS.values()), "duplicate entry"


def rows(names):
    out = []
    for i in range(0, len(names), 5):
        chunk = names[i:i + 5]
        out.append("                    " + ", ".join(f'"{n}"' for n in chunk)
                   + ("," if i + 5 < len(names) else ""))
    return out


new_block = [f'        for (String name : new String[] {{']
for b in ORDER:
    new_block = [l for l in new_block]
    new_block.append("        }) {") if False else None
# rebuild the static initialiser wholesale
init = ["    static {"]
for b in ORDER:
    init.append("        for (String name : new String[] {")
    init.extend(rows(BUCKETS[b]))
    init.append(f'        }}) {{')
    init.append(f'            IMPORTED_CATEGORY.put(name, "{b}");')
    init.append("        }")
init.append("    }")
init_src = "\n".join(init)

start = gui.index("    static {\n        for (String name : new String[] {")
end = gui.index("\n    }\n", gui.index('IMPORTED_CATEGORY.put(name, "MISC");')) + len("\n    }\n")
gui = gui[:start] + init_src + gui[end:]
open(GUI, "w", encoding="utf-8").write(gui)
print("\nClickGui table rewritten with", len(table), "entries")