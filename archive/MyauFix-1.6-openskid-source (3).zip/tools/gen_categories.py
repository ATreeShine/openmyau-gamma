#!/usr/bin/env python3
"""
Generate the category table for the imported OpenSkid modules in ClickGui,
and assert that every registered module lands in exactly one bucket.
"""
import re, sys, zipfile

MYAU = "/root/work/MyauMerged/src/main/java/myau/Myau.java"
JAR = "/root/work/MyauMerged/build/libs/MyauFix-1.6.jar"

COMBAT = """
ArmorBreaker AutoArmor AutoBed AutoBedDef AutoBlock AutoGapple AutoPlace AutoPot
AutoRod AutoSoup AutoWeapon BurstClicker
BedDefender BedProximityAlert BedWars BedwarUtils BreakProgress CheatDetector ClickAssits
Criticals DamageTags Displace FastBow FastUse FKCounter ForwardTrack Hitflick
HitParticleEffects
KeepRange KillEffect KillMessage KillSounds KillSults LegitReach MurderDetector Piercing
ProjectileAimBot Refill SmartBlinker SprintReset TargetESP TeamHealthDisplay ThrowAura
TickBase TimerRange
""".split()

MOVEMENT = """
AntiFalseFlag AutoHeadHitter BlockLadder BridgeAssist Clutch FreeLook Freecam GhostBlock
JumpReset
LadderClutch LegitScaffold MoveFix NoClickDelay NoWeb Parkour PearlSaver Phase SafeWalk
Spider Step StopMotion Tower VClip WaterClutch
""".split()

RENDER = """
Ambience Arrows BlockOverlay BlocksESP BridgeInfo Capes ClosestPlayerHUD DynamicIsland
EntityCulling
ESP2D FallIndicator FireBallPredict FPScounter Hotbar InventoryHUD ItemPhysics ItemTags
KeyStrokes LeapModeHUD MobESP MurderMystery PlayerList PotionHUD Radar RenderFixes
SkyWars SpeedBuilders Statistics SumoFences ThePitUtils TNTTimer WaterMark2 WoolWars
""".split()

PLAYER = """
AutoAuth AutoBuy AutoGG AutoHypixel AutoPlay AutoReconnect AutoRequeue AutoRespawn AutoWho
ModSpoofer MouseRawInput
""".split()

MISC = """
AntiBot DelayRemover Disabler DuelsStats ExploitFixer MegaWallsDetector Nuker Panic
PartyDetector PingSpoof ServerLag SkywarsAlerts SmartClicking StaffDetector ViewPackets
""".split()

BUCKETS = [("COMBAT", COMBAT), ("MOVEMENT", MOVEMENT), ("RENDER", RENDER),
           ("PLAYER", PLAYER), ("MISC", MISC)]

# ---- ground truth -----------------------------------------------------------
src = open(MYAU, encoding="utf-8").read()
registered = re.findall(r"moduleManager\.modules\.put\(openskid\.module\.modules\.(\w+)\.class", src)
z = zipfile.ZipFile(JAR)
display = {}
for c in registered:
    data = z.read(f"openskid/module/modules/{c}.class")
    m = re.search(rb"openskid-([A-Za-z0-9_]+)", data)
    display[m.group(1).decode()] = c          # display suffix -> class name

# Map bucket entries (class simple names) to display names.
by_class = {v: k for k, v in display.items()}

placed, dupes, unknown = {}, [], []
for name, items in BUCKETS:
    for it in items:
        cls = it
        if cls not in by_class:
            # tolerate the display-name spelling (FPScounter/Fpscounter)
            alt = next((c for c in by_class if c.lower() == it.lower()), None)
            if alt is None:
                unknown.append((name, it))
                continue
            cls = alt
        if cls in placed:
            dupes.append((cls, placed[cls], name))
            continue
        placed[cls] = name

missing = sorted(set(by_class) - set(placed))
print(f"registered modules : {len(registered)}")
print(f"placed             : {len(placed)}")
if unknown:
    print(f"UNKNOWN (not a module): {unknown}")
if dupes:
    print(f"DUPLICATES          : {dupes}")
if missing:
    print(f"MISSING             : {missing}")
if unknown or dupes or missing:
    sys.exit("coverage incomplete - fix the buckets above")

# ---- emit Java -------------------------------------------------------------
print()
for name, items in BUCKETS:
    print(f"{name}: {len(items)}")


def java_case(items):
    rows, cur = [], []
    for i, it in enumerate(items):
        cur.append(f'"{it}"' + ("," if i < len(items) - 1 else ""))
        if len(cur) == 5:
            rows.append("                    " + " ".join(cur))
            cur = []
    if cur:
        rows.append("                    " + " ".join(cur))
    return rows


out = []
for name, items in BUCKETS:
    out.append(f'            case {name}:')
    out.append("                return new String[] {")
    out.extend(java_case(items))
    out.append("                };")
open("/tmp/opencode/cat_table.txt", "w").write("\n".join(out))
print("\nwrote /tmp/opencode/cat_table.txt")
