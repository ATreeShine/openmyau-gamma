#!/usr/bin/env python3
"""Stage 3: point the ported modules at Myau's equivalent Module classes.

Ported files live in `openskid.module.modules` but their package-mates no longer
exist there, so a bare `HUD` / `KillAura` / `Scaffold` reference resolves to
nothing. Add the import of the Myau class that provides it.
"""
import os, re, sys, subprocess

DST = "/root/work/MyauMerged/src/main/java"
MODDIR = os.path.join(DST, "openskid/module/modules")

SYMBOLS = sorted({f[:-5] for f in os.listdir(os.path.join(DST, "myau/module/modules"))
                  if f.endswith(".java")})

changed_files = 0
added = {}
for f in sorted(os.listdir(MODDIR)):
    if not f.endswith(".java"):
        continue
    p = os.path.join(MODDIR, f)
    src = open(p, encoding="utf-8").read()
    body_start = src.index("\npublic ") if "\npublic " in src else src.index("{")
    header, body = src[:body_start], src[body_start:]
    new_imports = []
    for sym in SYMBOLS:
        if re.search(r"import\s+myau\.module\.modules\." + sym + r"\b", header):
            continue
        # used as a type / static access anywhere in the body?
        if not re.search(r"(?<![\w.$])" + sym + r"(?![\w])", body):
            continue
        new_imports.append(f"import myau.module.modules.{sym};")
    if not new_imports:
        continue
    # insert after the last existing import
    imports = list(re.finditer(r"^import .*;$", header, re.M))
    if imports:
        pos = imports[-1].end()
        header = header[:pos] + "\n" + "\n".join(new_imports) + header[pos:]
    else:
        header = header.rstrip("\n") + "\n\n" + "\n".join(new_imports) + "\n"
    open(p, "w", encoding="utf-8").write(header + body)
    for i in new_imports:
        added[i.split(".")[-1][:-1]] = added.get(i.split(".")[-1][:-1], 0) + 1
    changed_files += 1

print(f"imports added to {changed_files} module files")
print("most used:", sorted(added.items(), key=lambda kv: -kv[1])[:12])