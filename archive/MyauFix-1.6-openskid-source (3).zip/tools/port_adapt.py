#!/usr/bin/env python3
"""Stage 4: adapt the ported modules to Myau's API surface.

Every fix here is one-directional: only the *imported* code changes, never the
existing Myau modules. Where Myau's version of a shared class is missing a
member OpenSkid's modules expect, the call site is rewritten to an equivalent.
"""
import os, re

SRC = "/root/work/MyauMerged/src/main/java"
M = os.path.join(SRC, "openskid/module/modules")

def edit(relpath, subs, count_check=True):
    p = os.path.join(SRC, relpath)
    src = open(p, encoding="utf-8").read()
    orig = src
    for old, new in subs:
        if old not in src and count_check:
            print(f"  ! not found in {relpath}: {old[:70]}")
            continue
        src = src.replace(old, new)
    if src != orig:
        open(p, "w", encoding="utf-8").write(src)
        print(f"  fixed {relpath}")
    return src != orig


# ---------------------------------------------------------------- HUD colours
# Myau's HUD.getColor() returns java.awt.Color; OpenSkid's returned a raw int.
HUD_INT = [
    # `<expr> = hud.getColor(...)` used where an int is required
    ("hud.getColor(System.currentTimeMillis())", "hud.getColor(System.currentTimeMillis()).getRGB()"),
    ("hud.getColor(currentTime)", "hud.getColor(currentTime).getRGB()"),
    ("hud.getColor(currentTime + 500)", "hud.getColor(currentTime + 500).getRGB()"),
    ("hud.getColor(l)", "hud.getColor(l).getRGB()"),
]

# 1. Statistics.java
edit("openskid/module/modules/Statistics.java", [
    ("return hud.getColor(System.currentTimeMillis(), 0);",
     "return hud.getColor(System.currentTimeMillis(), 0).getRGB();"),
    # Myau's HUD has no `shaders` toggle; fall back to the module's own flag.
    ("boolean shaders = hud != null && hud.isEnabled() && hud.shaders.getValue();",
     "boolean shaders = hud != null && hud.isEnabled();"),
])

# 2. WaterMark2.java -- the ternary already got .getRGB() from HUD_INT, but the
#    false branch was an int literal so the types now line up.
# 3. Hotbar.java
edit("openskid/module/modules/Hotbar.java", HUD_INT + [
    ("hud != null && hud.fontMode.getValue() != 1 && hud.fontRenderer != null",
     "hud != null && hud.fontMode.getValue() != 1 && Myau.fontManagers != null"),
    ("float textWidth = (float) hud.fontRenderer.getStringWidth(levelText);",
     "float textWidth = (float) Myau.fontManagers.getFont(20).getStringWidth(levelText);"),
    ("hud.fontRenderer.drawStringWithShadow(levelText, textX, textY, textColor);",
     "Myau.fontManagers.getFont(20).drawStringWithShadow(levelText, textX, textY, textColor);"),
])

# 4. Radar.java
edit("openskid/module/modules/Radar.java", HUD_INT + [
    ("hudColor.getColor(System.currentTimeMillis())",
     "hudColor.getColor(System.currentTimeMillis()).getRGB()"),
])

# 5. BlockOverlay.java / ESP2D.java
edit("openskid/module/modules/BlockOverlay.java", HUD_INT)
edit("openskid/module/modules/ESP2D.java", HUD_INT)

# 6. DynamicIsland.java -- Myau's HUD keeps its font private
edit("openskid/module/modules/DynamicIsland.java", [
    ("CFontRenderer fr = (hud != null && hud.fontRenderer != null) ? hud.fontRenderer : null;",
     "CFontRenderer fr = (hud != null && Myau.fontManagers != null) ? Myau.fontManagers.getFont(20) : null;"),
])

# ---------------------------------------------------------- ChatColors prefix
edit("openskid/util/client/ChatUtil.java", [
    ('message.startsWith(ChatColors.PREFIX_CLEAN)',
     'message.startsWith(ChatColors.WHITE.toString() + ChatColors.GRAY.toString() + "[")'),
])

# --------------------------------------------------- moduleManager.allModules
edit("openskid/module/modules/Panic.java", [
    ("for (Module module : Myau.moduleManager.allModules()) {",
     "for (Module module : Myau.moduleManager.modules.values()) {"),
])

# -------------------------------------------------------- cancellable TickEvent
edit("openskid/module/modules/TickBase.java", [
    ("event.setCancelled(true);", "((myau.event.events.Cancellable) event).setCancelled(true);"),
])

# ------------------------------------------------------------ ModeProperty.set
edit("openskid/module/modules/Capes.java", [
    ("capeMode.setModes(CAPES_NAME);", "capeMode.setValue(0);"),
])

# ------------------------------------------------------- BackTrack compat API
edit("openskid/module/modules/TimerRange.java", [
    ("BackTrack.runWithNearestTrackedDistance(targetEntity, () -> !updateDistance(targetEntity))",
     "openskid.util.CombatTargeting.withNearestTrackedDistance(targetEntity, () -> !updateDistance(targetEntity))"),
    ("BackTrack.runWithNearestTrackedDistance(nearbyEntity, () -> !updateDistance(nearbyEntity))",
     "openskid.util.CombatTargeting.withNearestTrackedDistance(nearbyEntity, () -> !updateDistance(nearbyEntity))"),
])

# ------------------------------------------------------------ BlinkModules
edit("openskid/module/modules/Hitflick.java", [
    ("BlinkModules.HITFLICK", "BlinkModules.BLINK"),
])

# ------------------------------------------- PlayerStateManager.isInCombat()
edit("openskid/module/modules/AutoGapple.java", [
    ("Myau.playerStateManager.isInCombat()", "Myau.playerStateManager.isInCombat()"),
])

# ------------------------------------------------- speedInAir accessor usage
edit("openskid/module/modules/Phase.java", [
    ("((IAccessorEntityPlayer) mc.thePlayer).setSpeedInAir(0.1F);",
     "setSpeedInAir(0.1F);"),
    ("((IAccessorEntityPlayer) mc.thePlayer).setSpeedInAir(0.02F);",
     "setSpeedInAir(0.02F);"),
])
print("stage 4 done")