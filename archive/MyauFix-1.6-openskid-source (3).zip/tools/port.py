#!/usr/bin/env python3
"""Stage 2: rewrite vendored OpenSkid sources onto Myau's infrastructure."""
import os, re, sys, shutil

SRC = "/root/OpenSkid/src/main/java"
DST = "/root/work/MyauMerged/src/main/java"
OSK = os.path.join(SRC, "openskid")
DSTOSK = os.path.join(DST, "openskid")

MODULES = [l.strip().split("|")[0] for l in open("/tmp/jarcmp/classes.txt") if l.strip()]
# ClickGUIModule is Myau's GuiModule under a different name -> duplicate, skip it.
SKIP_MODULES = {"ClickGUIModule",   # == Myau GuiModule (same job)
                "ScriptModule"}     # adapter for the vendored RSL/keystrokesmod script engine

OVERLAP = set((
    "AimAssist Animations AntiAFK AntiDebuff AntiFireball AntiObbyTrap AntiObfuscate AntiVoid "
    "AutoAnduril AutoBlockIn AutoClicker AutoHeal AutoSwap AutoTool BackTrack BedESP BedNuker "
    "BedPlates BedTracker Blink BlockHit Chams ChestAura ChestESP ChestStealer ClientSpoofer ESP "
    "FakeLag FastPlace FlagDetector Fly FullBright GhostHand HUD HitBox HitSelect Indicators "
    "InvManager InvWalk InventoryClicker ItemESP Jesus KeepSprint KillAura KnockbackDelay LagRange "
    "LightningTracker LongJump MCF MoreKB NameTags NickHider NoFall NoHitDelay NoHurtCam "
    "NoJumpDelay NoRotate NoSlow Notifications Reach Scaffold Spamer Speed SpeedMine Sprint Stasis "
    "TargetHUD TargetStrafe Timer Tracers Trajectories Velocity ViewClip WaterMark Wtap Xray"
).split())

SHARED_PROPS = ["BooleanProperty", "ColorProperty", "FloatProperty", "IntProperty",
                "ModeProperty", "PercentProperty", "TextProperty"]
# vendored under openskid.property.properties.* (Myau has no equivalent)
NEW_PROPS = ["DragProperty", "ItemListProperty", "LongProperty"]
MYAU_MIXINS = {f[:-5] for f in os.listdir(os.path.join(DST, "myau/mixin")) if f.endswith(".java")}
OSK_MIXINS = {f[:-5] for f in os.listdir(os.path.join(OSK, "mixin"))
              if f.endswith(".java") and os.path.isfile(os.path.join(OSK, "mixin", f))}
SHARED_MIXINS = sorted(MYAU_MIXINS & OSK_MIXINS)
OSK_ONLY_MIXINS = sorted(OSK_MIXINS - MYAU_MIXINS)
MYAU_EVENTS = {f[:-5] for f in os.listdir(os.path.join(DST, "myau/events")) if f.endswith(".java")}


def port_modules():
    n = 0
    for m in MODULES:
        if m in SKIP_MODULES:
            continue
        s = os.path.join(OSK, "module/modules", m + ".java")
        d = os.path.join(DSTOSK, "module/modules", m + ".java")
        os.makedirs(os.path.dirname(d), exist_ok=True)
        shutil.copy2(s, d)
        n += 1
    print(f"  copied {n} module files (skipped {sorted(SKIP_MODULES)})")


def port_tree(rel):
    s = os.path.join(SRC, rel)
    n = 0
    for root, _d, files in os.walk(s):
        for f in files:
            if f.endswith(".java"):
                rel_f = os.path.relpath(os.path.join(root, f), SRC)
                d = os.path.join(DST, rel_f)
                os.makedirs(os.path.dirname(d), exist_ok=True)
                shutil.copy2(os.path.join(root, f), d)
                n += 1
    print(f"  vendored {rel}: {n} files")


def port_mixins():
    n = 0
    for m in OSK_ONLY_MIXINS:
        s = os.path.join(OSK, "mixin", m + ".java")
        d = os.path.join(DST, "myau/mixin", "Os" + m + ".java")
        os.makedirs(os.path.dirname(d), exist_ok=True)
        shutil.copy2(s, d)
        n += 1
    print(f"  vendored {n} OpenSkid-only mixins into myau/mixin as Os*")
    print(f"  reuse {len(SHARED_MIXINS)} shared mixins from myau/mixin")


def prefix_module_names():
    """Give every ported module the openskid- display prefix."""
    d = os.path.join(DSTOSK, "module/modules")
    n = 0
    for f in sorted(os.listdir(d)):
        if not f.endswith(".java") or f[:-5] in SKIP_MODULES:
            continue
        cls = f[:-5]
        p = os.path.join(d, f)
        src = open(p, encoding="utf-8").read()
        # only rewrite the Module super(...) name argument
        if '"openskid-' in src.split("\n\tsuper(", 1)[0][-200:]:
            new = src
        else:
            new = re.sub(r'(\n\s*super\()"([^"]+)"',
                         lambda mo: mo.group(1) + '"openskid-' + mo.group(2) + '"', src, count=1)
        if new != src:
            open(p, "w", encoding="utf-8").write(new)
            n += 1
    print(f"  prefixed display name in {n} module files")


def rewrite_file(path, extra=()):
    src = open(path, encoding="utf-8", errors="replace").read()
    orig = src
    # ---- module base / manager -------------------------------------------
    src = re.sub(r"\bopenskid\.module\.modules\b(?![\w.;])", "myau.module.modules", src)
    src = re.sub(r"\bopenskid\.module\.ModuleManager\b", "myau.module.ModuleManager", src)
    src = re.sub(r"\bopenskid\.module\.Module\b", "myau.module.Module", src)
    # ---- overlap modules --------------------------------------------------
    for name in sorted(OVERLAP, key=len, reverse=True):
        src = re.sub(r"\bopenskid\.module\.modules\." + name + r"\b",
                     "myau.module.modules." + name, src)
    # ---- property system --------------------------------------------------
    src = re.sub(r"\bopenskid\.property\.properties\.(\*|\w+)",
                 lambda m: "myau.property.properties." + m.group(1), src)
    for p_ in NEW_PROPS:  # these stay under openskid.property.properties.*
        src = src.replace("myau.property.properties." + p_, "openskid.property.properties." + p_)
    src = re.sub(r"\bopenskid\.property\.Property\b", "myau.property.Property", src)
    src = re.sub(r"\bopenskid\.property\.PropertyManager\b", "myau.property.PropertyManager", src)
    # ---- event system -----------------------------------------------------
    src = re.sub(r"\bopenskid\.event\.events\.callables\.", "myau.event.events.callables.", src)
    src = re.sub(r"\bopenskid\.event\.events\.", "myau.event.events.", src)
    src = re.sub(r"\bopenskid\.event\.types\.", "myau.event.types.", src)
    src = re.sub(r"\bopenskid\.event\.", "myau.event.", src)
    src = re.sub(r"\bopenskid\.events\.(\*|\w+)", lambda m: "myau.events." + m.group(1), src)
    # ---- managers ----------------------------------------------------------
    src = re.sub(r"\bopenskid\.management\.", "myau.management.", src)
    # ---- enums ------------------------------------------------------------
    src = re.sub(r"\bopenskid\.enums\.", "myau.enums.", src)
    # ---- config -----------------------------------------------------------
    src = re.sub(r"\bopenskid\.config\.", "myau.config.", src)
    # ---- mixins -----------------------------------------------------------
    for m in SHARED_MIXINS:
        src = re.sub(r"\bopenskid\.mixin\." + m + r"\b", "myau.mixin." + m, src)
    for m in OSK_ONLY_MIXINS:
        src = re.sub(r"\bopenskid\.mixin\." + m + r"\b", "myau.mixin.Os" + m, src)
    # ---- singleton --------------------------------------------------------
    src = re.sub(r"\bimport\s+openskid\.OpenSkid\s*;", "import myau.Myau;", src)
    src = re.sub(r"\bopenskid\.OpenSkid\b", "myau.Myau", src)
    src = re.sub(r"\bOpenSkid\.", "Myau.", src)
    src = re.sub(r"\bOpenSkid\.class\b", "Myau.class", src)
    # ---- per-file extras --------------------------------------------------
    for pat, rep in extra:
        src = re.sub(pat, rep, src)
    if src != orig:
        open(path, "w", encoding="utf-8").write(src)
        return True
    return False


def rewrite_all():
    changed = 0
    total = 0
    for root, _d, files in os.walk(DSTOSK):
        for f in files:
            if not f.endswith(".java"):
                continue
            p = os.path.join(root, f)
            total += 1
            if p.endswith((".class",)):
                continue
            # vendored Os* mixins live in myau/mixin
            extra = ()
            if os.path.basename(os.path.dirname(p)) == "mixin" and f.startswith("Os"):
                cls = f[:-5]
                extra = ((r"^package\s+openskid\.mixin\s*;", "package myau.mixin;"),
                         (r"\b(class|interface)\s+" + cls[2:] + r"\b", r"\1 " + cls))
            if rewrite_file(p, extra):
                changed += 1
    print(f"  rewrote {changed}/{total} vendored files")


def regen_mixins():
    """Refresh vendored mixin class names inside myau/mixin (Os* prefix)."""
    for m in OSK_ONLY_MIXINS:
        p = os.path.join(DST, "myau/mixin", "Os" + m + ".java")
        src = open(p, encoding="utf-8").read()
        src = re.sub(r"\b(class|interface)\s+" + m + r"\b", r"\1 Os" + m, src)
        open(p, "w", encoding="utf-8").write(src)


def main():
    stage = sys.argv[1] if len(sys.argv) > 1 else "all"
    print("== stage:", stage)
    if stage in ("all", "copy"):
        print("== copy ==")
        port_modules()
        port_tree("openskid/util")
        port_tree("openskid/font")
        port_tree("openskid/property/properties")
        port_mixins()
        # events: only what Myau lacks
        for f in sorted(os.listdir(os.path.join(OSK, "events"))):
            if f.endswith(".java") and f[:-5] not in MYAU_EVENTS:
                os.makedirs(os.path.join(DSTOSK, "events"), exist_ok=True)
                shutil.copy2(os.path.join(OSK, "events", f), os.path.join(DSTOSK, "events", f))
                print("  vendored event", f)
    if stage in ("all", "rewrite"):
        print("== rewrite ==")
        prefix_module_names()
        rewrite_all()
        regen_mixins()
    print("done")

if __name__ == "__main__":
    main()
