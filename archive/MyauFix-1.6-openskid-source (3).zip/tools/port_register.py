#!/usr/bin/env python3
"""Stage 5: register the imported modules in Myau's module list (Myau.java)."""
import os, re

MODDIR = "/root/work/MyauMerged/src/main/java/openskid/module/modules"
MYAU = "/root/work/MyauMerged/src/main/java/myau/Myau.java"

# only top-level classes are registrable; nested helper "modules" are inner classes
mods = []
for f in sorted(os.listdir(MODDIR)):
    if not f.endswith(".java"):
        continue
    src = open(os.path.join(MODDIR, f), encoding="utf-8").read()
    cls = f[:-5]
    # require `public class <Cls> extends Module`
    # class declaration may wrap onto the next line (e.g. `public class X\n extends Module`)
    if not re.search(r"^public (?:final )?class " + re.escape(cls)
                     + r"\b[^;{]*?extends Module\b", src, re.M | re.S):
        continue
    # must expose a public no-arg constructor
    if not re.search(r"public " + re.escape(cls) + r"\(\)", src):
        continue
    mods.append(cls)

print(f"{len(mods)} registrable modules")

src = open(MYAU, encoding="utf-8").read()
if "openskid.module.modules." in src:
    print("already registered"); raise SystemExit

# import the vendored package once
src = src.replace("import myau.property.Property;",
                  "import myau.property.Property;\nimport openskid.module.modules.*;", 1)
# Shadowing check: Myau.java already imports myau.module.modules.*, so the new
# on-demand import would be ambiguous. Use fully-qualified names instead.
src = src.replace("import openskid.module.modules.*;\n", "")

anchor = "        commandManager.commands.add(new BindCommand());"
assert anchor in src
reg = "".join(
    f"        Myau.moduleManager.modules.put(openskid.module.modules.{c}.class, new openskid.module.modules.{c}());\n"
    for c in mods
)
block = ("        // ------------------------------------------------------------------\n"
         "        // Modules imported from OpenSkid (openskid-<Name> display prefix).\n"
         "        // Registered into Myau's own ModuleManager/PropertyManager/EventManager so\n"
         "        // they show up in the ClickGui, bind to keys and save to configs like any\n"
         "        // native module. The classes themselves live under openskid.module.modules\n"
         "        // so no existing Myau module was touched.\n"
         "        // ------------------------------------------------------------------\n"
         + reg + "\n")
src = src.replace(anchor, block + anchor, 1)
open(MYAU, "w", encoding="utf-8").write(src)
print(f"registered {len(mods)} modules into Myau.java")