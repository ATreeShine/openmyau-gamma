#!/usr/bin/env python3
"""
Regression test for the ClickGui search click-through bug.

Reported symptom: with a search filter active, expanding a module and clicking its
settings would toggle a *different* module that was filtered out of view.

Cause: rows hidden by the search were skipped by the layout, so they kept a STALE
offsetY - the very position the visible row now occupies - and ClickGui still
dispatched mouseDown to every component in the column. Several hidden rows shared
the same stale offset, so the last one iterated won.

This test builds a real CategoryComponent over real module instances, applies a
real filter, and then clicks exactly where the visible row is drawn.
"""
import glob, os, subprocess, sys, tempfile, zipfile

JAR = sys.argv[1] if len(sys.argv) > 1 else \
    "/root/work/MyauMerged/build/intermediates/MyauFix-1.6-non-obfuscated-with-deps.jar"
LOOM = ("/root/.gradle/caches/essential-loom/1.8.9/"
        "de.oceanlabs.mcp.mcp_stable.1_8_9.22-1.8.9-forge-1.8.9-11.15.1.2318-1.8.9")
MC = os.path.join(LOOM, "minecraft-mapped.jar")
FORGE = os.path.join(LOOM, "forge", "forge-mapped.jar")
GLSTUB = "/tmp/myau-glstub-classes"
for p in (JAR, MC, FORGE, GLSTUB):
    if not os.path.exists(p):
        sys.exit("missing input: " + p)

WORK = tempfile.mkdtemp(prefix="myau-click-")

HARNESS = r'''
import java.lang.reflect.*;
import java.util.*;

public class Click {
    static int fails = 0;
    static void ok(boolean c, String m) {
        System.out.println((c ? "  OK   " : "  FAIL ") + m);
        if (!c) fails++;
    }

    static sun.misc.Unsafe UNSAFE;

    public static void main(String[] args) throws Exception {
        java.lang.reflect.Field uf = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
        uf.setAccessible(true);
        UNSAFE = (sun.misc.Unsafe) uf.get(null);

        // Myau's Module.toggle() reads Myau.moduleManager + HUD; stand them up.
        Class<?> myauCls = Class.forName("myau.Myau");
        Class<?> mmCls = Class.forName("myau.module.ModuleManager");
        Object mm = mmCls.getDeclaredConstructor().newInstance();
        myauCls.getField("moduleManager").set(null, mm);
        myauCls.getField("propertyManager").set(null,
                Class.forName("myau.property.PropertyManager").getDeclaredConstructor().newInstance());
        Object hud = Class.forName("myau.module.modules.HUD").getDeclaredConstructor().newInstance();
        @SuppressWarnings("unchecked")
        Map<Object, Object> mods = (Map<Object, Object>) mmCls.getField("modules").get(mm);
        mods.put(hud.getClass(), hud);

        Class<?> modBase = Class.forName("myau.module.Module");
        Class<?> catCls = Class.forName("myau.ui.components.CategoryComponent");
        Class<?> compCls = Class.forName("myau.ui.components.ModuleComponent");

        // Three modules that all match the filter "a", so more than one row is visible.
        // CLASS simple names (the display name is openskid-<name>)
        String[] names = {"KillAura", "AutoArmor", "AutoPot"};
        // Real instances: ModuleComponent matches the filter on mod.getName(), and an
        // Unsafe-allocated module has a null name.
        List<Object> modules = new ArrayList<Object>();
        for (String n : names) {
            modules.add(Class.forName("openskid.module.modules." + n)
                    .getDeclaredConstructor().newInstance());
        }

        // Myau.init() registers each module's Property fields before the gui is built;
        // ModuleComponent's constructor requires that map to be populated.
        Object pm = myauCls.getField("propertyManager").get(null);
        @SuppressWarnings("unchecked")
        Map<Object, Object> props = (Map<Object, Object>)
                pm.getClass().getField("properties").get(pm);
        Class<?> propBase = Class.forName("myau.property.Property");
        for (Object m : modules) {
            List<Object> list = new ArrayList<Object>();
            for (Field f : m.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                Object v = f.get(m);
                if (propBase.isInstance(v)) {
                    propBase.getMethod("setOwner", modBase).invoke(v, m);
                    list.add(v);
                }
            }
            props.put(m.getClass(), list);
        }

        Constructor<?> ctor = catCls.getConstructor(String.class, List.class);
        Object cat = ctor.newInstance("Combat", modules);
        catCls.getMethod("setOpened", boolean.class).invoke(cat, true);
        catCls.getMethod("setX", int.class).invoke(cat, 10);
        catCls.getMethod("setY", int.class).invoke(cat, 10);
        List<Component> rows = (List<Component>) catCls.getMethod("getModules").invoke(cat);
        ok(rows.size() == 3, "category built 3 rows");

        Method setFilter = catCls.getMethod("setFilter", String.class);
        setFilter.invoke(cat, "auto");
        catCls.getMethod("updateAllOffsets").invoke(cat);

        // which rows survived the filter?
        List<Integer> visible = new ArrayList<Integer>();
        for (int i = 0; i < rows.size(); i++) {
            if ((Boolean) compCls.getMethod("isVisible").invoke(rows.get(i))) visible.add(i);
        }
        ok(visible.size() == 2, "filter 'auto' keeps exactly 2 rows, hides 1 (got " + visible.size() + ")");
        ok(!visible.contains(0), "the hidden row is openskid-KillAura (index 0)");

        int catX = (Integer) catCls.getMethod("getX").invoke(cat);
        int catY = (Integer) catCls.getMethod("getY").invoke(cat);

        // Click row-by-row exactly where each VISIBLE row is drawn.
        int hiddenToggled = 0, visibleToggled = 0;
        for (int i = 0; i < rows.size(); i++) {
            Component row = rows.get(i);
            if (!(Boolean) compCls.getMethod("isVisible").invoke(row)) continue;
            int offsetY = (Integer) compCls.getField("offsetY").get(row);
            int y = catY + offsetY + 8;                       // middle of the row
            row.mouseDown(catX + 20, y, 0);                  // left click = toggle
            if ((Boolean) modBase.getMethod("isEnabled").invoke(modules.get(i))) visibleToggled++;
        }
        ok(visibleToggled == 2, "both visible rows toggled when clicked (got " + visibleToggled + ")");

        // The decisive check: is the hidden module still disabled?
        boolean hiddenEnabled = (Boolean) modBase.getMethod("isEnabled").invoke(modules.get(0));
        ok(!hiddenEnabled,
                "openskid-KillAura (filtered out) was NOT toggled by clicks meant for visible rows");

        // Now click every pixel of the hidden row's own old position as well - if the
        // stale offset were still live this would toggle it.
        int hiddenOffset = (Integer) compCls.getField("offsetY").get(rows.get(0));
        ok(hiddenOffset < -1000,
                "hidden row's offset was parked off-screen instead of left stale ("
                        + hiddenOffset + ")");
        for (int dy = 0; dy < 40; dy++) {
            rows.get(0).mouseDown(catX + 20, catY + hiddenOffset + dy, 0);
        }
        ok(!(Boolean) modBase.getMethod("isEnabled").invoke(modules.get(0)),
                "clicking the hidden row's old position still toggles nothing");

        // clearing the filter must bring everything back and re-lay it out
        setFilter.invoke(cat, "");
        catCls.getMethod("updateAllOffsets").invoke(cat);
        int allVisible = 0;
        for (Component row : rows) {
            if ((Boolean) compCls.getMethod("isVisible").invoke(row)) allVisible++;
        }
        ok(allVisible == 3, "clearing the filter restores all 3 rows (got " + allVisible + ")");

        System.out.println(fails == 0 ? "\nCLICK OK" : "\nCLICK FAILURES: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }

    interface Component {}
}
'''
stub = os.path.join(WORK, "Click.java")
open(stub, "w").write(HARNESS)

WANT = ("org.lwjgl.lwjgl", "com.google.guava", "org.apache.logging.log4j",
        "net.java.dev.jna", "net.sf.jopt-simple", "com.google.code.gson",
        "io.netty", "commons-io", "commons-codec", "org.apache.httpcomponents",
        "org.ow2.asm", "com.paulscode", "org.apache.commons", "it.unimi.dsi",
        "org.jline", "net.java.jinput", "net.minecraft", "com.ibm.icu", "com.mojang")
deps = []
for g in os.listdir("/root/.gradle/caches/modules-2/files-2.1"):
    if any(g == w or g.startswith(w + ".") for w in WANT):
        deps += [j for j in glob.glob(f"/root/.gradle/caches/modules-2/files-2.1/{g}/**/*.jar",
                                      recursive=True)
                 if not j.endswith(("-sources.jar", "-javadoc.jar"))]
deps = [GLSTUB] + [d for d in sorted(set(deps)) if "/org.lwjgl.lwjgl/" not in d]
CP = ":".join([JAR, MC, FORGE] + deps)
javac = "/usr/lib/jvm/java-8-openjdk-amd64/bin/javac"
java = "/usr/lib/jvm/java-8-openjdk-amd64/bin/java"

# the harness uses the real myau.ui.Component type, drop the local stand-in
src = open(stub).read().replace("\n    interface Component {}\n", "\n")
src = src.replace("import java.lang.reflect.*;",
                  "import java.lang.reflect.*;\nimport myau.ui.Component;")
open(stub, "w").write(src)

r = subprocess.run([javac, "-nowarn", "-proc:none", "-cp", CP, "-d", WORK, stub],
                   capture_output=True, text=True)
if r.returncode != 0:
    print("harness compile failed:\n" + r.stderr[:2000])
    sys.exit(2)

r = subprocess.run([java, "-cp", ":".join([WORK] + CP.split(":")), "Click"],
                   capture_output=True, text=True, timeout=300)
print(r.stdout.strip())
if r.returncode != 0 and r.stderr.strip():
    print("--- stderr (tail) ---")
    print("\n".join(r.stderr.strip().split("\n")[-12:]))
sys.exit(r.returncode)