# MyauFix 1.6 + OpenSkid module merge

This is your **MyauFix-1.6** client (the one with the Yuri codes) with every
OpenSkid module you did not already have, added as `openskid-<Name>`.

Nothing that existed before was modified. All 135 original modules
(`AimAssist`, `KillAura`, the 53 `Yuri*` ones, `CSCAFFOLD`, …) still have their
original class names, display names, properties and behaviour.

---

## What was added

**205 modules** - that is *every* module OpenSkid ships - registered in
`myau/Myau.java` into Myau's own `ModuleManager`, so they appear in the ClickGui,
take keybinds, are toggleable from chat, and are saved/loaded by your configs
exactly like your own modules.

That includes the 76 that OpenSkid shares a name with Myau's own modules, so
`openskid-KillAura` sits next to `KillAura` and `openskid-Scaffold` next to
`Scaffold`. Each client keeps its own copy; the `openskid-` prefix is what tells
them apart in the gui, in chat and in the config file.

**All 205 ship default-OFF.** Upstream OpenSkid has ten of them default-on
(`Animations`, `AntiBot`, `DynamicIsland`, `FullBright`, `Hotbar`, `HUD`,
`NoHitDelay`, `Notifications`, `RenderFixes`, `Sprint`); those defaults were
flipped to off, because dropping a whole second client in should not silently
switch on a second HUD, a second notifications system and a second Sprint. Turn
on what you actually want.

The client therefore has **340 modules** in total: your original 135 (all still
present, all still named exactly as before) plus the 205 imported ones.

| group | modules |
|---|---|
| combat | AimBot-ish set (`ThrowAura`, `Hitflick`, `Piercing`, `KillSults`, `AutoWeapon`, `ArmorBreaker`, `ClickAssits`, `ProjectileAimBot`, `TargetESP`, `Criticals`, `KeepRange`, …) |
| movement | `Spider`, `Tower`, `Parkour`, `LadderClutch`, `WaterClutch`, `SafeWalk`, `StopMotion`, `ForwardTrack`, `Displace`, `Phase`, `VClip`, `SafeWalk`, `NoClickDelay`, `SprintReset`, `MoveFix`, `JumpReset`, `ExploitFixer`, `SmartClicking` |
| player/world | `AntiBot`, `AntiFalseFlag`, `StaffDetector`, `PartyDetector`, `MurderDetector`, `MurderMystery`, `MegaWallsDetector`, `CheatDetector`, `ModSpoofer`, `NoWeb`, `AutoReconnect`, `AutoRespawn`, `AutoRequeue`, `Panic` |
| BedWars / BedWars-like | `AutoBed`, `AutoBedDef`, `BedDefender`, `BedProximityAlert`, `BedwarUtils`, `BedWars`, `BridgeAssist`, `BridgeInfo`, `SumoFences`, `BlockLadder`, `GhostBlock`, `BreakProgress`, `AutoWho`, `AutoHeadHitter` |
| PvP modes | `AutoPot`, `AutoSoup`, `Gapple` (the class is `AutoGapple`), `AutoRod`, `AutoGG`, `AutoPlay`, `AutoBuy`, `AutoHypixel`, `AutoArmor`, `AutoPlace`, `AutoBlock`, `Clutch`, `KillAura`-adjacent damage tags |
| ESP / rendering | `BlocksESP`, `MobESP`, `ESP2D`, `ItemTags`, `DamageTags`, `BlockOverlay`, `BreakProgress`, `TargetESP`, `HitParticleEffects`, `KillEffect`, `EntityCulling`, `RenderFixes`, `ProjectileAimBot`, `FireBallPredict`, `Trajectories`-style previews |
| HUD / info | `Radar`, `Hotbar`, `PlayerList`, `KeyStrokes`, `InventoryHUD`, `PotionHUD`, `LeapModeHUD`, `ClosestPlayerHUD`, `DynamicIsland`, `ItemPhysics`, `TeamHealthDisplay`, `FallIndicator`, `FPScounter`, `FKCounter`, `Statistics`, `WaterMark2`, `TNTTimer`, `KillMessage`, `KillSounds`, `DuelsStats`, `SkyWars`, `WoolWars`, `ThePitUtils` |
| misc | `LegitScaffold`, `LegitReach`, `Disabler`, `Freecam`, `FreeLook`, `DelayRemover`, `ServerLag`, `SmartBlinker`, `BurstClicker`, `NoClickDelay`, `AutoAuth`, `ItemPhysics`, `ViewPackets`, `PingSpoof`, `EntityCulling` |

Full list of display names:

```
openskid-AimAssist        openskid-Ambience         openskid-Animations       openskid-AntiAFK
openskid-AntiBot          openskid-AntiDebuff       openskid-AntiFalseFlag    openskid-AntiFireball
openskid-AntiObbyTrap     openskid-AntiObfuscate    openskid-AntiVoid         openskid-ArmorBreaker
openskid-Arrows           openskid-AutoAnduril      openskid-AutoArmor        openskid-AutoAuth
openskid-AutoBed          openskid-AutoBedDef       openskid-AutoBlock        openskid-AutoBlockIn
openskid-AutoBuy          openskid-AutoClicker      openskid-AutoGG           openskid-AutoHeadHitter
openskid-AutoHeal         openskid-AutoHypixel      openskid-AutoPlace        openskid-AutoPlay
openskid-AutoPot          openskid-AutoReconnect    openskid-AutoRequeue      openskid-AutoRespawn
openskid-AutoRod          openskid-AutoSoup         openskid-AutoSwap         openskid-AutoTool
openskid-AutoWeapon       openskid-AutoWho          openskid-Backtrack        openskid-BedDefender
openskid-BedESP           openskid-BedNuker         openskid-BedPlates        openskid-BedProximityAlert
openskid-BedTracker       openskid-BedWars          openskid-BedwarUtils      openskid-Blink
openskid-BlockHit         openskid-BlockLadder      openskid-BlockOverlay     openskid-BlocksESP
openskid-BreakProgress    openskid-BridgeAssist     openskid-BridgeInfo       openskid-BurstClicker
openskid-Capes            openskid-Chams            openskid-CheatDetector    openskid-ChestAura
openskid-ChestESP         openskid-ChestStealer     openskid-ClickAssits      openskid-ClickGUI
openskid-ClientSpoofer    openskid-ClosestPlayerHUD openskid-Clutch           openskid-Criticals
openskid-DamageTags       openskid-DelayRemover     openskid-Disabler         openskid-Displace
openskid-DuelsStats       openskid-DynamicIsland    openskid-ESP              openskid-ESP2D
openskid-EntityCulling    openskid-ExploitFixer     openskid-FKCounter        openskid-FakeLag
openskid-FallIndicator    openskid-FastBow          openskid-FastPlace        openskid-FastUse
openskid-FireBallPredict  openskid-FlagDetector     openskid-Fly              openskid-ForwardTrack
openskid-Fpscounter       openskid-FreeLook         openskid-Freecam          openskid-Fullbright
openskid-Gapple           openskid-GhostBlock       openskid-GhostHand        openskid-HUD
openskid-HitBox           openskid-HitParticleEffectsopenskid-HitSelect        openskid-Hitflick
openskid-Hotbar           openskid-Indicators       openskid-InvManager       openskid-InvWalk
openskid-InventoryClicker openskid-InventoryHUD     openskid-ItemESP          openskid-ItemPhysics
openskid-ItemTags         openskid-Jesus            openskid-JumpReset        openskid-KeepRange
openskid-KeepSprint       openskid-KeyStrokes       openskid-KillAura         openskid-KillEffect
openskid-KillMessage      openskid-KillSounds       openskid-KillSults        openskid-KnockbackDelay
openskid-LadderClutch     openskid-LagRange         openskid-LeapModeHUD      openskid-LegitReach
openskid-LegitScaffold    openskid-LightningTracker openskid-LongJump         openskid-MCF
openskid-MegaWallsDetectoropenskid-MobESP           openskid-ModSpoofer       openskid-MoreKB
openskid-MouseRawInput    openskid-MoveFix          openskid-MurderDetector   openskid-MurderMystery
openskid-NameTags         openskid-NickHider        openskid-NoClickDelay     openskid-NoFall
openskid-NoHitDelay       openskid-NoHurtCam        openskid-NoJumpDelay      openskid-NoRotate
openskid-NoSlow           openskid-NoWeb            openskid-Notifications    openskid-Nuker
openskid-Panic            openskid-Parkour          openskid-PartyDetector    openskid-PearlSaver
openskid-Phase            openskid-Piercing         openskid-PingSpoof        openskid-PlayerList
openskid-PotionHUD        openskid-ProjectileAimBot openskid-Radar            openskid-Reach
openskid-Refill           openskid-RenderFixes      openskid-SafeWalk         openskid-Scaffold
openskid-ServerLag        openskid-SkyWars          openskid-SkywarsAlerts    openskid-SmartBlinker
openskid-SmartClicking    openskid-Spammer          openskid-Speed            openskid-SpeedBuilders
openskid-SpeedMine        openskid-Spider           openskid-Sprint           openskid-SprintReset
openskid-StaffDetector    openskid-Stasis           openskid-Statistics       openskid-Step
openskid-StopMotion       openskid-SumoFences       openskid-TNTTimer         openskid-TargetESP
openskid-TargetHUD        openskid-TargetStrafe     openskid-TeamHealthDisplayopenskid-ThePitUtils
openskid-ThrowAura        openskid-TickBase         openskid-Timer            openskid-TimerRange
openskid-Tower            openskid-Tracers          openskid-Trajectories     openskid-VClip
openskid-Velocity         openskid-ViewClip         openskid-ViewPackets      openskid-WTap
openskid-WaterClutch      openskid-WaterMark        openskid-WaterMark2       openskid-WoolWars
openskid-Xray
```

---

## How it was done (so you can maintain it)

The two clients are the same codebase lineage (both are 1.8.9 Forge with
`mcp_stable` 22-1.8.9), which is why this merges cleanly. The imported code
keeps its original `openskid.*` package root, so nothing of yours was renamed
and no duplicate infrastructure was introduced.

```
src/main/java/
├── myau/                          <- YOUR client, untouched except 3 additive edits
│   ├── Myau.java                  + registers the 128 imported modules
│   │                              + `lagCore` + `fontManagers` singletons
│   ├── module/Module.java         + optional `description` ctor overload
│   ├── management/LagCore.java    NEW: packet-hold hub for the imported modules
│   ├── mixin/Os*.java             NEW: 6 OpenSkid-only mixins (auto-discovered)
│   └── ...                        everything else byte-identical to before
└── openskid/                      <- everything imported from OpenSkid
    ├── module/modules/            128 modules, display name "openskid-<Name>"
    ├── util/                      OpenSkid utils (kept together so they stay consistent)
    ├── font/                      OpenSkid fonts (assets under assets/openskid/font/)
    ├── property/properties/       DragProperty, ItemListProperty, LongProperty
    └── events/JumpEvent.java      the one event Myau did not have
```

Infrastructure is **shared, not duplicated**: the imported modules extend
`myau.module.Module`, use `myau.property.*`, `myau.event.*`, `myau.events.*`,
`myau.enums.*`, `myau.management.*` and `myau.mixin.*`. That is what makes them
show up in your GUI and config with no extra work.

### The only 3 edits to your own code
1. `myau/Myau.java` – registration block + the two new singletons.
2. `myau/module/Module.java` – added a `Module(name, enabled, hidden, description)`
   overload and `getDescription()` (additive; existing ctors untouched).
3. `myau/management/LagCore.java` – new file, nothing overwritten.

### ClickGui changes

The ClickGui listed its modules in five hardcoded arrays and then **threw** from
its constructor if any registered module was missing:

```java
throw new RuntimeException(module.getClass().getName() + " is unregistered to click gui.");
```

Registering the 128 imported modules without adding them to those arrays meant
the gui threw on open, so it never appeared. Fixed in `myau/ui/ClickGui.java`:

* `importedCategory(Module)` maps each imported module's class name to a column
  (COMBAT 62, MOVEMENT 37, RENDER 52, PLAYER 27, MISC 27). Nothing is hardcoded
  per-instance any more, and the lookup is by class name so a display-name change
  cannot break it. The 76 imported twins are placed in the same column as the
  Myau module they mirror, so `openskid-KillAura` lands directly under
  `KillAura`.
* Uncategorised modules now fall back to Misc **and print a line naming them**,
  instead of bricking the gui. Adding a module can no longer take the gui down.
* Your 135 existing column entries are untouched - the table only matches
  `openskid.*` class names, and a test asserts the two sets do not overlap.

### ClickGui search: click-through fix

Filtering exposed a second bug. Rows hidden by the search were skipped by the
layout, so they kept whatever `offsetY` they had *before* the filter was applied
- which is exactly where the newly visible row now sits. `ClickGui` still
dispatched `mouseDown` to every component in the column, so a hidden row claimed
the click and toggled itself. Because many hidden rows shared the same stale
offset, the last one iterated won, which is why it looked like a *random* module
turning itself on.

Fixed at three levels:

* `ClickGui` now skips invisible rows in the mouse-down, mouse-release,
  hover-update and key-dispatch loops (a hidden `BindComponent` could previously
  swallow a key too);
* `ModuleComponent.mouseDown` / `mouseReleased` / `update` return immediately when
  the row is not visible, so the component defends itself regardless of caller;
* `CategoryComponent` parks hidden rows at offset `-100000` instead of leaving a
  stale offset, removing the root cause rather than only guarding it.

`ModuleComponent.isVisible()` also null-guards the module name, so a module with
no name can no longer NPE the whole render loop.

### ClickGui search

260+ modules in five columns is a lot to scroll, so the gui now has a search box
in the top-right corner:

* click it to focus, type to filter, `x` or Backspace/Delete to erase,
  Esc releases focus without clearing, Backspace-then-empty also releases;
* filtering matches the module's display name, case-insensitively, so typing
  `aur` finds both `KillAura` and `openskid-ThrowAura`;
* a filtered-out module is never drawn, never counted towards column height, and
  never scrolls, so the scrollbar shrinks to what is actually left;
* clicking the box no longer also toggles the Combat column underneath it;
* focus is required for typing, so the arrow keys still change values in an
  expanded settings panel.

### The 6 new mixins
`OsMixinRenderEntityItem`, `OsMixinGuiChat`, `OsMixinGuiNewChat`,
`OsMixinEntityLivingBaseAnimations`, `OsIAccessorTimer`,
`OsIAccessorS27PacketExplosion`. The `Os` prefix keeps them from colliding with
your existing mixins; Myau's mixin config auto-discovers everything in
`myau.mixin`, and the injector's `mixins.myau.runtime.json` was updated to list
them too.

---

## Things worth knowing

* **`openskid-ClickGUI` opens Myau's ClickGui.** Upstream it cycles five of its own
  ClickGui skins; those skins are a separate UI subsystem and are not vendored, so
  this module drives Myau's gui instead. Same job, one implementation.
* **`ScriptModule` is the one module still absent.** Out of 211 files in
  OpenSkid's module folder, 205 are imported. The other 6 are 3 helper classes
  (no gui entry) plus `ScriptModule`, which is only an adapter around the
  separately vendored `keystrokesmod`/RSL obfuscated script engine - it has no
  meaning without that third project compiled in.
* **`ScaffoldPlacementExecutor` / `ScaffoldPlacementPlanner` /
  `ScaffoldRotationController` are back.** In batch 1 they were dead code (only
  OpenSkid's own `Scaffold` ever instantiated them, and that was not ported yet).
  Now that `openskid-Scaffold` is here, they are imported with it. They are
  helper classes, not modules, so they do not appear in the gui.
* **6 OpenSkid-only mixins were kept, 1 was dropped**: `MixinGuiMultiplayer`
  only added the ViaVersion server-list slider and needs the whole ViaMCP stack.
* **Multi-version (ViaVersion) features are not ported** — they are a separate
  subsystem in OpenSkid, not modules.
* **`openskid-Capes` says "OpenSkid"** in its watermark because that string is
  hardcoded upstream. Edit `Capes.java` if you want it to say Myau.
* **`DragProperty` / `ItemListProperty` / `LongProperty`** save and load through
  your config system normally, but your ClickGui has no component for those three
  types, so a `DragProperty` is not rendered as a draggable row (no crash — the
  ClickGui just skips property types it does not know).
* **Three new globals**: `Myau.lagCore`, `Myau.fontManagers` and
  `Myau.notificationManager`. `lagCore` is the
  packet-hold hub used by `SmartBlinker`, `Displace` and `ServerLag`; it is
  separate from your `lagManager`, so do not run those at the same time as
  `Blink`/`FakeLag`/`BackTrack`.
* **`openskid-Gapple` (class `AutoGapple`) tracks combat locally** (your `PlayerStateManager` has
  no `isInCombat()`, and adding one would have meant editing your class).

---

## Build

```bash
./gradlew remapJar        # -> build/libs/MyauFix-1.6.jar
```

Then merge the attach agent (that is what produces `OpenMyau-Fix.zip`):

```bash
cd /tmp/opencode/myau-build
MYAU_CLIENT_JAR=/root/work/MyauMerged/build/libs/MyauFix-1.6.jar python3 package_new.py
```

`package_new.py` is `package.py` with the client-jar path taken from the
environment instead of being hardcoded.

## Verification

`port_*.py` are the (re-runnable) import scripts; `verify_click.py` is the
regression test for the search click-through bug (it was confirmed to fail against
the unfixed gui, with the hidden row sitting at offset 16). `verify_final.py`
checks the packaged jar statically; `verify_runtime.py` loads every module class from the
built jar and reflects over it (handlers, properties, instantiation, toggle);
`verify_clickgui.py` proves every module reaches a gui column by calling the real
shipped `importedCategory()` reflectively. `make_gl_stubs.py` generates the
signature-accurate LWJGL stubs the runtime tests need, since there is no GL
context here.

```
verify_final.py     -> ALL CHECKS PASSED         jar integrity, mixin wiring,
                                                 205 classes resolve, 340 module
                                                 names unique, Java 8 bytecode
verify_runtime.py   -> RUNTIME OK                205/205 classes load, 448 handlers
                                                 all take Myau events, 1802 property
                                                 fields, 189/205 instantiate+toggle,
                                                 16 env-limited, 0 real failures
verify_clickgui.py  -> CLICKGUI CATEGORISATION OK  340 modules, 205/205 categorised,
                                                 throw removed, 340 unique display
                                                 names
verify_click.py     -> CLICK OK                   builds a real filtered CategoryComponent,
                                                 clicks where visible rows are drawn and
                                                 asserts the filtered-out row stays
                                                 off and untoggled
source zip          -> compiles clean from scratch
```

The 16 environment-limited modules are classified **by cause**, not by a hardcoded
list: 12 whose `onEnabled`/`onDisabled` touch `mc.thePlayer`/`theWorld` (no world is
loaded in the harness), 2 whose constructor touches the render engine or display
settings, and 2 that need Minecraft's live block/item registry. There are **zero**
real failures - every module that can be exercised headlessly constructs and
toggles cleanly.

### Known risk: the shader-blur HUD modules

`openskid-Hotbar`, `openskid-DynamicIsland`, `openskid-RenderFixes` and
`openskid-Statistics` are the only modules using OpenSkid's glassmorphism blur,
which looks like this:

```java
BlurUtils.prepareBlur();                             // binds an offscreen framebuffer
RoundedUtils.drawRound(x, y, w, h, r, Color.WHITE);  // draws a WHITE stencil into it
BlurUtils.blurEnd(2, 4.0f);                          // composites back to the screen
```

If anything throws between the bind and the unbind, the game keeps drawing into
that offscreen buffer and shows a **white screen**. The first three are
**default-enabled upstream**, so they were on the moment the jar was dropped in.
They are left default-enabled here to match upstream, but if you ever see a white
screen again, turn those three off first (or run with the all-off config).

**What was NOT verified: in-game behaviour.** There is no Minecraft client, GL
context or game account in this environment, so nobody has seen these modules
render or fire a packet yet. Compile, packaging, class wiring, event/property
plumbing, module lifecycle and gui categorisation are verified; actual gameplay
and on-screen appearance are not.
