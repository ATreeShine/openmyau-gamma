package myau.ui;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import myau.Myau;
import myau.font.UFontRenderer;
import myau.module.Module;
import myau.module.modules.*;
import myau.ui.components.BindComponent;
import myau.ui.components.CategoryComponent;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.List;

public class ClickGui extends GuiScreen {
    private static ClickGui instance;
    private final File configFile = new File("./config/Myau/", "clickgui.txt");
    private final ArrayList<CategoryComponent> categoryList;

    private UFontRenderer modernFontRenderer;
    private FontRenderer currentRenderer;

    // ---- module search -----------------------------------------------------
    // With the OpenSkid import there are 260+ modules, so the gui needs a filter.
    // Typing is only captured while the box has focus (click it first); otherwise
    // keys still reach the expanded settings, which use arrows to change modes.
    private final StringBuilder search = new StringBuilder();
    private boolean searchFocused;
    private int searchX, searchY, searchW, searchH;
    private int caretTick;

    public ClickGui() {
        instance = this;

        List<Module> combatModules = new ArrayList<>();
        combatModules.add(Myau.moduleManager.getModule(AimAssist.class));
        combatModules.add(Myau.moduleManager.getModule(AutoClicker.class));
        combatModules.add(Myau.moduleManager.getModule(AutoProjectiles.class));
        combatModules.add(Myau.moduleManager.getModule(KillAura.class));
        combatModules.add(Myau.moduleManager.getModule(Wtap.class));
        combatModules.add(Myau.moduleManager.getModule(Velocity.class));
        combatModules.add(Myau.moduleManager.getModule(Reach.class));
        combatModules.add(Myau.moduleManager.getModule(TargetStrafe.class));
        combatModules.add(Myau.moduleManager.getModule(NoHitDelay.class));
        combatModules.add(Myau.moduleManager.getModule(AntiFireball.class));
        combatModules.add(Myau.moduleManager.getModule(KnockbackDelay.class));
        combatModules.add(Myau.moduleManager.getModule(LagRange.class));
        combatModules.add(Myau.moduleManager.getModule(HitBox.class));
        combatModules.add(Myau.moduleManager.getModule(MoreKB.class));
        combatModules.add(Myau.moduleManager.getModule(HitSelect.class));
        combatModules.add(Myau.moduleManager.getModule(BackTrack.class));
        combatModules.add(Myau.moduleManager.getModule(BlockHit.class));
        combatModules.add(Myau.moduleManager.getModule(YuriAutoProjectiles.class));
        combatModules.add(Myau.moduleManager.getModule(YuriAutoPot.class));
        combatModules.add(Myau.moduleManager.getModule(YuriBackTrack.class));
        combatModules.add(Myau.moduleManager.getModule(YuriCriticals.class));
        combatModules.add(Myau.moduleManager.getModule(YuriKillAura.class));
        combatModules.add(Myau.moduleManager.getModule(YuriHitSelect.class));
        combatModules.add(Myau.moduleManager.getModule(YuriTickBase.class));
        combatModules.add(Myau.moduleManager.getModule(YuriWTap.class));
        combatModules.add(Myau.moduleManager.getModule(YuriVelocity.class));
        combatModules.add(Myau.moduleManager.getModule(YuriAutoExtinguish.class));
        combatModules.add(Myau.moduleManager.getModule(YuriBowAimbot.class));
        combatModules.add(Myau.moduleManager.getModule(YuriLagRange.class));
        combatModules.add(Myau.moduleManager.getModule(YuriTargetStrafe.class));

        List<Module> movementModules = new ArrayList<>();
        movementModules.add(Myau.moduleManager.getModule(AntiAFK.class));
        movementModules.add(Myau.moduleManager.getModule(Fly.class));
        movementModules.add(Myau.moduleManager.getModule(Speed.class));
        movementModules.add(Myau.moduleManager.getModule(LongJump.class));
        movementModules.add(Myau.moduleManager.getModule(Sprint.class));
        movementModules.add(Myau.moduleManager.getModule(Jesus.class));
        movementModules.add(Myau.moduleManager.getModule(Blink.class));
        movementModules.add(Myau.moduleManager.getModule(NoFall.class));
        movementModules.add(Myau.moduleManager.getModule(NoSlow.class));
        movementModules.add(Myau.moduleManager.getModule(KeepSprint.class));
        movementModules.add(Myau.moduleManager.getModule(Eagle.class));
        movementModules.add(Myau.moduleManager.getModule(NoJumpDelay.class));
        movementModules.add(Myau.moduleManager.getModule(AntiVoid.class));
        movementModules.add(Myau.moduleManager.getModule(Stasis.class));
        movementModules.add(Myau.moduleManager.getModule(YuriPhase.class));
        movementModules.add(Myau.moduleManager.getModule(YuriSafeWalk.class));
        movementModules.add(Myau.moduleManager.getModule(YuriStep.class));
        movementModules.add(Myau.moduleManager.getModule(YuriWaterWalk.class));
        movementModules.add(Myau.moduleManager.getModule(YuriSpeed.class));
        movementModules.add(Myau.moduleManager.getModule(YuriFlight.class));
        movementModules.add(Myau.moduleManager.getModule(YuriSprint.class));
        movementModules.add(Myau.moduleManager.getModule(YuriStasis.class));
        movementModules.add(Myau.moduleManager.getModule(YuriNoSlow.class));

        List<Module> renderModules = new ArrayList<>();
        renderModules.add(Myau.moduleManager.getModule(Animations.class));
        renderModules.add(Myau.moduleManager.getModule(ESP.class));
        renderModules.add(Myau.moduleManager.getModule(Chams.class));
        renderModules.add(Myau.moduleManager.getModule(FullBright.class));
        renderModules.add(Myau.moduleManager.getModule(Tracers.class));
        renderModules.add(Myau.moduleManager.getModule(NameTags.class));
        renderModules.add(Myau.moduleManager.getModule(Xray.class));
        renderModules.add(Myau.moduleManager.getModule(TargetHUD.class));
        renderModules.add(Myau.moduleManager.getModule(Indicators.class));
        renderModules.add(Myau.moduleManager.getModule(BedESP.class));
        renderModules.add(Myau.moduleManager.getModule(ItemESP.class));
        renderModules.add(Myau.moduleManager.getModule(PotionEffects.class));
        renderModules.add(Myau.moduleManager.getModule(ViewClip.class));
        renderModules.add(Myau.moduleManager.getModule(NoHurtCam.class));
        renderModules.add(Myau.moduleManager.getModule(HUD.class));
        renderModules.add(Myau.moduleManager.getModule(GuiModule.class));
        renderModules.add(Myau.moduleManager.getModule(ChestESP.class));
        renderModules.add(Myau.moduleManager.getModule(Trajectories.class));
        renderModules.add(Myau.moduleManager.getModule(Notifications.class));
        renderModules.add(Myau.moduleManager.getModule(WaterMark.class));
        renderModules.add(Myau.moduleManager.getModule(TabGui.class));
        renderModules.add(Myau.moduleManager.getModule(BedPlates.class));
        renderModules.add(Myau.moduleManager.getModule(YuriAmbience.class));
        renderModules.add(Myau.moduleManager.getModule(YuriBreadcrumbs.class));

        List<Module> playerModules = new ArrayList<>();
        playerModules.add(Myau.moduleManager.getModule(AutoHeal.class));
        playerModules.add(Myau.moduleManager.getModule(AutoTool.class));
        playerModules.add(Myau.moduleManager.getModule(AutoSwap.class));
        playerModules.add(Myau.moduleManager.getModule(ChestAura.class));
        playerModules.add(Myau.moduleManager.getModule(ChestStealer.class));
        playerModules.add(Myau.moduleManager.getModule(FakeLag.class));
        playerModules.add(Myau.moduleManager.getModule(InvManager.class));
        playerModules.add(Myau.moduleManager.getModule(InvWalk.class));
        playerModules.add(Myau.moduleManager.getModule(Scaffold.class));
        playerModules.add(Myau.moduleManager.getModule(AutoBlockIn.class));
        playerModules.add(Myau.moduleManager.getModule(SpeedMine.class));
        playerModules.add(Myau.moduleManager.getModule(FastPlace.class));
        playerModules.add(Myau.moduleManager.getModule(GhostHand.class));
        playerModules.add(Myau.moduleManager.getModule(MCF.class));
        playerModules.add(Myau.moduleManager.getModule(AntiDebuff.class));
        playerModules.add(Myau.moduleManager.getModule(myau.module.modules.Timer.class));
        playerModules.add(Myau.moduleManager.getModule(YuriAutoArmor.class));
        playerModules.add(Myau.moduleManager.getModule(YuriFastBreak.class));
        playerModules.add(Myau.moduleManager.getModule(YuriFastUse.class));
        playerModules.add(Myau.moduleManager.getModule(YuriRefill.class));
        playerModules.add(Myau.moduleManager.getModule(YuriRegen.class));
        playerModules.add(Myau.moduleManager.getModule(YuriGUIClicker.class));
        playerModules.add(Myau.moduleManager.getModule(YuriAntiVoid.class));
        playerModules.add(Myau.moduleManager.getModule(YuriNoFall.class));
        playerModules.add(Myau.moduleManager.getModule(YuriEagle.class));
        playerModules.add(Myau.moduleManager.getModule(YuriInvMove.class));
        playerModules.add(Myau.moduleManager.getModule(YuriAntiFireball.class));
        playerModules.add(Myau.moduleManager.getModule(YuriBlink.class));
        playerModules.add(Myau.moduleManager.getModule(YuriStealer.class));
        playerModules.add(Myau.moduleManager.getModule(YuriBreaker.class));
        playerModules.add(Myau.moduleManager.getModule(YuriBedDefender.class));
        playerModules.add(Myau.moduleManager.getModule(YuriManager.class));
        playerModules.add(Myau.moduleManager.getModule(YuriLongJump.class));
        playerModules.add(Myau.moduleManager.getModule(YuriScaffold.class));
        playerModules.add(Myau.moduleManager.getModule(CSCAFFOLD.class));

        List<Module> miscModules = new ArrayList<>();
        miscModules.add(Myau.moduleManager.getModule(Spammer.class));
        miscModules.add(Myau.moduleManager.getModule(BedNuker.class));
        miscModules.add(Myau.moduleManager.getModule(BedTracker.class));
        miscModules.add(Myau.moduleManager.getModule(LightningTracker.class));
        miscModules.add(Myau.moduleManager.getModule(NoRotate.class));
        miscModules.add(Myau.moduleManager.getModule(NickHider.class));
        miscModules.add(Myau.moduleManager.getModule(AntiObbyTrap.class));
        miscModules.add(Myau.moduleManager.getModule(AntiObfuscate.class));
        miscModules.add(Myau.moduleManager.getModule(AutoAnduril.class));
        miscModules.add(Myau.moduleManager.getModule(InventoryClicker.class));
        miscModules.add(Myau.moduleManager.getModule(ClientSpoofer.class));
        miscModules.add(Myau.moduleManager.getModule(FlagDetector.class));
        miscModules.add(Myau.moduleManager.getModule(YuriAntiBot.class));
        miscModules.add(Myau.moduleManager.getModule(YuriAutoSwap.class));
        miscModules.add(Myau.moduleManager.getModule(YuriDerp.class));
        miscModules.add(Myau.moduleManager.getModule(YuriDisabler.class));
        miscModules.add(Myau.moduleManager.getModule(YuriInputFixes.class));
        miscModules.add(Myau.moduleManager.getModule(YuriInsults.class));
        miscModules.add(Myau.moduleManager.getModule(YuriItemDelays.class));
        miscModules.add(Myau.moduleManager.getModule(YuriTimer.class));
        miscModules.add(Myau.moduleManager.getModule(YuriBedWarsUtility.class));
        miscModules.add(Myau.moduleManager.getModule(YuriFriends.class));
        miscModules.add(Myau.moduleManager.getModule(YuriToggleSounds.class));

        Set<Module> registered = new HashSet<>();
        registered.addAll(combatModules);
        registered.addAll(movementModules);
        registered.addAll(renderModules);
        registered.addAll(playerModules);
        registered.addAll(miscModules);

        // Modules imported from OpenSkid (openskid-*). They are placed by class name
        // rather than by the hardcoded lists above, so a new import can never silently
        // disappear from the gui.
        List<String> uncategorised = new ArrayList<>();
        for (Module module : Myau.moduleManager.modules.values()) {
            if (registered.contains(module)) {
                continue;
            }
            String bucket = importedCategory(module);
            if (bucket == null) {
                uncategorised.add(module.getName());
                bucket = "MISC";
            }
            switch (bucket) {
                case "COMBAT":
                    combatModules.add(module);
                    break;
                case "MOVEMENT":
                    movementModules.add(module);
                    break;
                case "RENDER":
                    renderModules.add(module);
                    break;
                case "PLAYER":
                    playerModules.add(module);
                    break;
                default:
                    miscModules.add(module);
                    break;
            }
            registered.add(module);
        }
        if (!uncategorised.isEmpty()) {
            // Visible, but never fatal - a module landing in Misc beats a dead gui.
            System.out.println("[ClickGui] no category for " + uncategorised + ", put in Misc");
        }

        Comparator<Module> comparator = Comparator.comparing(m -> m.getName().toLowerCase());
        combatModules.sort(comparator);
        movementModules.sort(comparator);
        renderModules.sort(comparator);
        playerModules.sort(comparator);
        miscModules.sort(comparator);

        this.categoryList = new ArrayList<>();
        int topOffset = 5;

        CategoryComponent combat = new CategoryComponent("Combat", combatModules);
        combat.setY(topOffset);
        categoryList.add(combat);
        topOffset += 20;

        CategoryComponent movement = new CategoryComponent("Movement", movementModules);
        movement.setY(topOffset);
        categoryList.add(movement);
        topOffset += 20;

        CategoryComponent render = new CategoryComponent("Render", renderModules);
        render.setY(topOffset);
        categoryList.add(render);
        topOffset += 20;

        CategoryComponent player = new CategoryComponent("Player", playerModules);
        player.setY(topOffset);
        categoryList.add(player);
        topOffset += 20;

        CategoryComponent misc = new CategoryComponent("Misc", miscModules);
        misc.setY(topOffset);
        categoryList.add(misc);

        loadPositions();
        for (CategoryComponent cat : categoryList) {
            cat.updateAllOffsets();
        }
    }

    public static ClickGui getInstance() {
        return instance;
    }

    /** Imported OpenSkid class name -> ClickGui column. */
    private static final Map<String, String> IMPORTED_CATEGORY = new HashMap<>();

    static {
        for (String name : new String[] {
                    "AimAssist", "AntiFireball", "ArmorBreaker", "AutoArmor", "AutoBed",
                    "AutoBedDef", "AutoBlock", "AutoClicker", "AutoGapple", "AutoPlace",
                    "AutoPot", "AutoRod", "AutoSoup", "AutoWeapon", "BackTrack",
                    "BedDefender", "BedProximityAlert", "BedWars", "BedwarUtils", "BlockHit",
                    "BreakProgress", "BurstClicker", "CheatDetector", "ClickAssits", "ClickGUIModule",
                    "Criticals", "DamageTags", "Displace", "FKCounter", "FastBow",
                    "FastUse", "ForwardTrack", "HitBox", "HitParticleEffects", "HitSelect",
                    "Hitflick", "KeepRange", "KillAura", "KillEffect", "KillMessage",
                    "KillSounds", "KillSults", "KnockbackDelay", "LagRange", "LegitReach",
                    "MoreKB", "MurderDetector", "NoHitDelay", "Piercing", "ProjectileAimBot",
                    "Reach", "Refill", "SmartBlinker", "SprintReset", "TargetESP",
                    "TargetStrafe", "TeamHealthDisplay", "ThrowAura", "TickBase", "TimerRange",
                    "Velocity", "Wtap"
        }) {
            IMPORTED_CATEGORY.put(name, "COMBAT");
        }
        for (String name : new String[] {
                    "AntiAFK", "AntiFalseFlag", "AntiVoid", "AutoHeadHitter", "Blink",
                    "BlockLadder", "BridgeAssist", "Clutch", "Fly", "FreeLook",
                    "Freecam", "GhostBlock", "Jesus", "JumpReset", "KeepSprint",
                    "LadderClutch", "LegitScaffold", "LongJump", "MoveFix", "NoClickDelay",
                    "NoFall", "NoJumpDelay", "NoSlow", "NoWeb", "Parkour",
                    "PearlSaver", "Phase", "SafeWalk", "Speed", "Spider",
                    "Sprint", "Stasis", "Step", "StopMotion", "Tower",
                    "VClip", "WaterClutch"
        }) {
            IMPORTED_CATEGORY.put(name, "MOVEMENT");
        }
        for (String name : new String[] {
                    "Ambience", "Animations", "Arrows", "BedESP", "BedPlates",
                    "BlockOverlay", "BlocksESP", "BridgeInfo", "Capes", "Chams",
                    "ChestESP", "ClosestPlayerHUD", "DynamicIsland", "ESP", "ESP2D",
                    "EntityCulling", "FPScounter", "FallIndicator", "FireBallPredict", "FullBright",
                    "HUD", "Hotbar", "Indicators", "InventoryHUD", "ItemESP",
                    "ItemPhysics", "ItemTags", "KeyStrokes", "LeapModeHUD", "MobESP",
                    "MurderMystery", "NameTags", "NoHurtCam", "Notifications", "PlayerList",
                    "PotionHUD", "Radar", "RenderFixes", "SkyWars", "SpeedBuilders",
                    "Statistics", "SumoFences", "TNTTimer", "TargetHUD", "ThePitUtils",
                    "Tracers", "Trajectories", "ViewClip", "WaterMark", "WaterMark2",
                    "WoolWars", "Xray"
        }) {
            IMPORTED_CATEGORY.put(name, "RENDER");
        }
        for (String name : new String[] {
                    "AntiDebuff", "AutoAuth", "AutoBlockIn", "AutoBuy", "AutoGG",
                    "AutoHeal", "AutoHypixel", "AutoPlay", "AutoReconnect", "AutoRequeue",
                    "AutoRespawn", "AutoSwap", "AutoTool", "AutoWho", "ChestAura",
                    "ChestStealer", "FakeLag", "FastPlace", "GhostHand", "InvManager",
                    "InvWalk", "MCF", "ModSpoofer", "MouseRawInput", "Scaffold",
                    "SpeedMine", "Timer"
        }) {
            IMPORTED_CATEGORY.put(name, "PLAYER");
        }
        for (String name : new String[] {
                    "AntiBot", "AntiObbyTrap", "AntiObfuscate", "AutoAnduril", "BedNuker",
                    "BedTracker", "ClientSpoofer", "DelayRemover", "Disabler", "DuelsStats",
                    "ExploitFixer", "FlagDetector", "InventoryClicker", "LightningTracker", "MegaWallsDetector",
                    "NickHider", "NoRotate", "Nuker", "Panic", "PartyDetector",
                    "PingSpoof", "ServerLag", "SkywarsAlerts", "SmartClicking", "Spammer",
                    "StaffDetector", "ViewPackets"
        }) {
            IMPORTED_CATEGORY.put(name, "MISC");
        }
    }
    /**
     * Which ClickGui column an imported OpenSkid module belongs in, matched on class name.
     *
     * @return "COMBAT", "MOVEMENT", "RENDER", "PLAYER", "MISC", or null when unknown.
     */
    private static String importedCategory(Module module) {
        return IMPORTED_CATEGORY.get(module.getClass().getSimpleName());
    }

    public FontRenderer getCurrentRenderer() {
        return currentRenderer;
    }

    private FontRenderer getFontRenderer() {
        GuiModule guiModule = (GuiModule) Myau.moduleManager.getModule(GuiModule.class);
        if (guiModule != null && guiModule.modernFont.getValue()) {
            if (modernFontRenderer == null) {
                try {
                    modernFontRenderer = new UFontRenderer("GoogleSans-Regular", 18);
                } catch (Exception e) {
                    modernFontRenderer = null;
                }
            }
            if (modernFontRenderer != null) {
                return modernFontRenderer;
            }
        } else {
            modernFontRenderer = null;
        }
        return mc.fontRendererObj;
    }

    private int getFontHeight() {
        return getFontRenderer().FONT_HEIGHT;
    }

    @Override
    public void initGui() {
        super.initGui();
    }

    @Override
    public void drawScreen(int x, int y, float p) {
        drawRect(0, 0, this.width, this.height, new Color(0, 0, 0, 100).getRGB());

        currentRenderer = getFontRenderer();

        currentRenderer.drawStringWithShadow("Myau " + Myau.version, 4, this.height - 3 - currentRenderer.FONT_HEIGHT * 2, new Color(60, 162, 253).getRGB());
        currentRenderer.drawStringWithShadow("dev, Mornly", 4, this.height - 3 - currentRenderer.FONT_HEIGHT, new Color(60, 162, 253).getRGB());

        for (CategoryComponent category : categoryList) {
            category.render(currentRenderer);
            category.handleDrag(x, y);

            for (Component module : category.getModules()) {
                // rows hidden by the search are not drawn, so they must not react
                if (module.isVisible()) {
                    module.update(x, y);
                }
            }
        }

        renderSearchBox();

        int wheel = Mouse.getDWheel();
        if (wheel != 0) {
            int scrollDir = wheel > 0 ? 1 : -1;
            for (CategoryComponent category : categoryList) {
                category.onScroll(x, y, scrollDir);
            }
        }
    }

    private void renderSearchBox() {
        FontRenderer fr = getFontRenderer();
        int h = fr.FONT_HEIGHT + 4;
        int w = 130;
        searchW = w;
        searchH = h;
        searchX = this.width - w - 4;
        searchY = 4;

        boolean focused = this.searchFocused;
        int bg = focused ? new Color(0, 0, 0, 170).getRGB() : new Color(0, 0, 0, 110).getRGB();
        Gui.drawRect(searchX - 1, searchY - 1, searchX + w + 1, searchY + h + 1, new Color(60, 162, 253, focused ? 200 : 80).getRGB());
        Gui.drawRect(searchX, searchY, searchX + w, searchY + h, bg);

        String text = this.search.length() == 0 ? (focused ? "" : "search modules") : this.search.toString();
        int color = this.search.length() == 0 ? new Color(120, 120, 120).getRGB() : -1;
        fr.drawString(text, searchX + 4, searchY + 3, color, false);

        if (this.search.length() > 0) {
            fr.drawString("x", searchX + w - 10, searchY + 3, new Color(200, 200, 200).getRGB(), false);
        }

        if (focused && (this.caretTick++ / 20) % 2 == 0 && this.search.length() > 0) {
            int caretX = searchX + 4 + fr.getStringWidth(this.search.toString());
            Gui.drawRect(caretX, searchY + 2, caretX + 1, searchY + h - 2, new Color(60, 162, 253).getRGB());
        }
    }

    private boolean isInSearchBox(int x, int y) {
        return x >= searchX && x <= searchX + searchW && y >= searchY && y <= searchY + searchH;
    }

    private boolean isOnClearButton(int x, int y) {
        return this.search.length() > 0 && x >= searchX + searchW - 12 && x <= searchX + searchW - 2
                && y >= searchY && y <= searchY + searchH;
    }

    private void applyFilter() {
        String filter = this.search.toString();
        for (CategoryComponent cat : categoryList) {
            cat.setFilter(filter);
            cat.updateAllOffsets();
        }
    }

    private void clearSearch() {
        this.search.setLength(0);
        this.searchFocused = false;
        applyFilter();
    }

    @Override
    public void mouseClicked(int x, int y, int mouseButton) {
        for (CategoryComponent category : categoryList) {
            category.updateAllOffsets();
        }

        // The search box owns clicks inside itself, otherwise clicking it would also
        // toggle the Combat column underneath.
        if (isInSearchBox(x, y)) {
            if (mouseButton == 0 && isOnClearButton(x, y)) {
                clearSearch();
            } else {
                this.searchFocused = true;
            }
            return;
        }
        if (this.searchFocused) {
            // clicking away keeps the text but releases the keyboard
            this.searchFocused = false;
        }

        Iterator<CategoryComponent> btnCat = categoryList.iterator();
        while (true) {
            CategoryComponent category;
            do {
                do {
                    if (!btnCat.hasNext()) {
                        return;
                    }

                    category = btnCat.next();
                    if (category.insideArea(x, y) && !category.isHovered(x, y) && !category.mousePressed(x, y) && mouseButton == 0) {
                        category.mousePressed(true);
                        category.xx = x - category.getX();
                        category.yy = y - category.getY();
                    }

                    if (category.mousePressed(x, y) && mouseButton == 0) {
                        category.setOpened(!category.isOpened());
                    }

                    if (category.isHovered(x, y) && mouseButton == 0) {
                        category.setPin(!category.isPin());
                    }
                } while (!category.isOpened());
            } while (category.getModules().isEmpty());

            for (Component c : category.getModules()) {
                if (c.isVisible()) {
                    c.mouseDown(x, y, mouseButton);
                }
            }
        }
    }

    @Override
    public void mouseReleased(int x, int y, int mouseButton) {
        for (CategoryComponent category : categoryList) {
            category.updateAllOffsets();
        }

        Iterator<CategoryComponent> iterator = categoryList.iterator();

        CategoryComponent categoryComponent;
        while (iterator.hasNext()) {
            categoryComponent = iterator.next();
            if (mouseButton == 0) {
                categoryComponent.mousePressed(false);
            }
        }

        iterator = categoryList.iterator();

        while (true) {
            do {
                do {
                    if (!iterator.hasNext()) {
                        return;
                    }

                    categoryComponent = iterator.next();
                } while (!categoryComponent.isOpened());
            } while (categoryComponent.getModules().isEmpty());

            for (Component component : categoryComponent.getModules()) {
                if (component.isVisible()) {
                    component.mouseReleased(x, y, mouseButton);
                }
            }
        }
    }

    @Override
    public void keyTyped(char typedChar, int key) {
        // Search box has the keyboard: swallow everything except ESC.
        if (this.searchFocused) {
            if (key == Keyboard.KEY_ESCAPE) {
                this.searchFocused = false;
                return;
            }
            if (key == Keyboard.KEY_BACK && this.search.length() > 0) {
                this.search.deleteCharAt(this.search.length() - 1);
                applyFilter();
                return;
            }
            if (key == Keyboard.KEY_DELETE && this.search.length() > 0) {
                this.search.deleteCharAt(this.search.length() - 1);
                applyFilter();
                return;
            }
            // printable characters only; ignore control keys and function keys
            if (typedChar >= ' ' && typedChar != 127 && this.search.length() < 32) {
                this.search.append(typedChar);
                applyFilter();
            }
            return;
        }

        boolean hasBinding = false;
        for (CategoryComponent cat : categoryList) {
            for (Component comp : cat.getModules()) {
                // a row hidden by the search must not be able to capture a keybind
                if (comp.isVisible() && comp instanceof BindComponent && ((BindComponent) comp).isBinding) {
                    hasBinding = true;
                    break;
                }
            }
            if (hasBinding) break;
        }

        if (hasBinding) {
            for (CategoryComponent cat : categoryList) {
                for (Component comp : cat.getModules()) {
                    if (comp.isVisible()) {
                        comp.keyTyped(typedChar, key);
                    }
                }
            }
        } else {
            if (key == 1) {
                this.mc.displayGuiScreen(null);
            } else {
                for (CategoryComponent cat : categoryList) {
                    if (!cat.isOpened()) continue;
                    for (Component comp : cat.getModules()) {
                        if (comp.isVisible()) {
                            comp.keyTyped(typedChar, key);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onGuiClosed() {
        savePositions();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void savePositions() {
        JsonObject json = new JsonObject();
        for (CategoryComponent cat : categoryList) {
            JsonObject pos = new JsonObject();
            pos.addProperty("x", cat.getX());
            pos.addProperty("y", cat.getY());
            pos.addProperty("open", cat.isOpened());
            json.add(cat.getName(), pos);
        }
        try (FileWriter writer = new FileWriter(configFile)) {
            new GsonBuilder().setPrettyPrinting().create().toJson(json, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadPositions() {
        if (!configFile.exists()) return;
        try (FileReader reader = new FileReader(configFile)) {
            JsonObject json = new JsonParser().parse(reader).getAsJsonObject();
            for (CategoryComponent cat : categoryList) {
                if (json.has(cat.getName())) {
                    JsonObject pos = json.getAsJsonObject(cat.getName());
                    cat.setX(pos.get("x").getAsInt());
                    cat.setY(pos.get("y").getAsInt());
                    cat.setOpened(pos.get("open").getAsBoolean());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}