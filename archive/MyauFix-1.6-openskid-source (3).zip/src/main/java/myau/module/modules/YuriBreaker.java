package myau.module.modules;

import myau.Myau;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.event.types.Priority;
import myau.events.PacketEvent;
import myau.events.Render2DEvent;
import myau.events.UpdateEvent;
import myau.mixin.IAccessorPlayerControllerMP;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.ModeProperty;
import myau.util.ItemUtil;
import myau.util.PacketUtil;
import myau.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockBed;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;

import java.util.ArrayList;
import java.util.Arrays;

// ported from ddlc.yuri.modules.impl.player.BreakerModule
// ported: ProgressBarManager progress-bar rendering dropped (Yuri-only HUD infra); a plain
//         RenderUtil rectangle progress bar is drawn instead at the same screen position.
// ported: AuraModule.target kill-aura guard replaced by reading OpenMyau's KillAura target.
// ported: RotationManager.setRotations(...) replaced by UpdateEvent#setRotation (silent rotations).
// ported: BreakerWhitelistManager inlined below (scan for the nearest bed every 20 ticks,
//         whitelist it + its 6 neighbours, reset on "Protect your bed" chat).
public class YuriBreaker extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public final ModeProperty breakType = new ModeProperty("Break Mode", 0, new String[]{"Vanilla", "Hypixel", "Legit"});
    public final FloatProperty breakrange = new FloatProperty("Breaker Range", 3.0F, 3.0F, 6.0F);
    public final BooleanProperty autoTool = new BooleanProperty("Auto Tool", true);
    public final BooleanProperty swing = new BooleanProperty("Visual Swing", true);
    public final BooleanProperty moveFix = new BooleanProperty("Move Fix", true);
    public final BooleanProperty whitelist = new BooleanProperty("Whitelist", true);
    public final BooleanProperty progressBar = new BooleanProperty("Progress Bar", true);

    public BlockPos breakPos;
    public BlockPos bedPos;

    public float blockDamage;
    public float lastBlockDamage;
    public int blockDamageCD;
    public int spoofTick = 0;
    public ItemStack st = null;
    private int oldSlot = -1;
    private boolean isBreaking = false;

    private final ArrayList<BlockPos> whitelisted = new ArrayList<BlockPos>();
    private boolean scanCheck = true;
    private int scanCooldown = 0;

    public YuriBreaker() {
        super("Yuri Breaker", false);
    }

    @Override
    public void onEnabled() {
        this.blockDamage = 0;
        this.lastBlockDamage = this.blockDamage;
        this.blockDamageCD = 5;
        this.bedPos = null;
        this.breakPos = null;
        this.oldSlot = -1;
        this.isBreaking = false;
    }

    @Override
    public void onDisabled() {
        if (this.blockDamage > 0 && this.blockDamage < 1 && this.breakPos != null) {
            PacketUtil.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, this.breakPos, EnumFacing.UP));
        }
        this.blockDamage = 0;
        this.lastBlockDamage = this.blockDamage;
        this.blockDamageCD = 0;
        this.bedPos = null;
        this.breakPos = null;
        this.whitelisted.clear();
        this.scanCheck = true;
        this.scanCooldown = 0;
        this.resetSlot();
    }

    private void resetSlot() {
        if (this.isBreaking) {
            if (this.autoTool.getValue() && this.oldSlot >= 0 && this.oldSlot < 9 && mc.thePlayer != null) {
                mc.thePlayer.inventory.currentItem = this.oldSlot;
                if (mc.playerController != null) {
                    ((IAccessorPlayerControllerMP) mc.playerController).callSyncCurrentPlayItem();
                }
            }
            this.oldSlot = -1;
            this.isBreaking = false;
        }
    }
private EntityLivingBase auraTarget() {
        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        if (killAura != null && killAura.isEnabled()) {
            return killAura.getTarget();
        }
        return null;
    }

    private void sendBlockBreak(BlockPos pos) {
        this.lastBlockDamage = this.blockDamage;
        if (pos == null) {
            if (this.blockDamageCD > 0) {
                this.blockDamageCD--;
            }
            this.resetSlot();
            return;
        }

        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (block instanceof BlockAir) {
            this.blockDamage = 0;
            this.blockDamageCD = 6;
            this.resetSlot();
            return;
        }
        if (this.blockDamageCD > 0) {
            this.blockDamageCD--;
            return;
        }

        this.spoofTick = this.getSlotFromBlock(block);
        if (this.spoofTick == -1) {
            this.spoofTick = mc.thePlayer.inventory.currentItem;
        }
        this.st = mc.thePlayer.inventory.getStackInSlot(this.spoofTick);

        if (this.blockDamage == 0f) {
            if (this.auraTarget() != null && this.breakPos != null) {
                this.resetSlot();
                return;
            } else {
                this.startBreak();
            }
        } else {
            if (this.autoTool.getValue() && this.spoofTick != -1 && mc.thePlayer.inventory.currentItem != this.spoofTick) {
                mc.thePlayer.inventory.currentItem = this.spoofTick;
                if (mc.playerController != null) {
                    ((IAccessorPlayerControllerMP) mc.playerController).callSyncCurrentPlayItem();
                }
            }
            this.addDamage(this.breakPos);
        }

        if (this.blockDamage >= 1f && this.auraTarget() == null) {
            this.stopBreak();
        }
    }

    private void sendAnimReqPacket(Packet<?> packet) {
        PacketUtil.sendPacket(packet);
        if (this.swing.getValue()) {
            mc.thePlayer.swingItem();
        } else {
            PacketUtil.sendPacket(new C0APacketAnimation());
        }
    }

    private void startBreak() {
        if (!this.isBreaking) {
            this.oldSlot = mc.thePlayer.inventory.currentItem;
            this.isBreaking = true;
        }
        if (this.autoTool.getValue() && this.spoofTick != -1) {
            mc.thePlayer.inventory.currentItem = this.spoofTick;
            if (mc.playerController != null) {
                ((IAccessorPlayerControllerMP) mc.playerController).callSyncCurrentPlayItem();
            }
        }

        this.sendAnimReqPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, this.breakPos, EnumFacing.UP));
        this.addDamage(this.breakPos);
    }
// ported: Yuri's patched EntityPlayer.getToolDigEfficiency(Block, ItemStack) 2-arg overload does
    // not exist in vanilla 1.8.9; ItemUtil.getToolEfficiency(stack, block) is the exact equivalent.
    private void addDamage(BlockPos pos) {
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        ItemStack held = mc.thePlayer.inventory.getStackInSlot(mc.thePlayer.inventory.currentItem);
        ItemStack tool = held != null ? held : this.st;
        float addyDMG = ItemUtil.getToolEfficiency(tool, block) / block.getBlockHardness(mc.theWorld, pos) / 30.0F;
        if (!mc.thePlayer.onGround) {
            addyDMG /= 5;
        }
        this.blockDamage += addyDMG;
        mc.theWorld.sendBlockBreakProgress(mc.thePlayer.getEntityId(), pos, (int) (this.blockDamage * 10.0F) - 1);
    }

    private void stopBreak() {
        this.sendAnimReqPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.breakPos, EnumFacing.UP));
        this.blockDamage = 0;
        this.blockDamageCD = 5;
        mc.theWorld.setBlockToAir(this.breakPos);
        this.resetSlot();
    }

    @EventTarget(Priority.HIGHEST)
    public void onPreUpdate(UpdateEvent event) {
        if (mc.thePlayer == null || mc.theWorld == null || event.getType() != EventType.PRE) {
            return;
        }

        this.updateWhitelist();

        BlockPos closestBedPos = this.findBed(this.breakrange.getValue());

        if (closestBedPos != null) {
            if (!this.checkPosValidity(closestBedPos)) {
                this.resetSlot();
                return;
            }
            if (this.blockDamageCD != 0) {
                if (this.breakType.getValue() == 1) {
                    if (this.isBedOpen(closestBedPos)) {
                        this.breakPos = closestBedPos;
                    } else {
                        if (this.breakPos == null) {
                            this.breakPos = this.getNearestBlock(closestBedPos);
                        } else if (!(mc.theWorld.getBlockState(this.breakPos).getBlock() instanceof BlockAir)
                                && !mc.theWorld.getBlockState(this.breakPos).getBlock().isFullBlock()) {
                            this.breakPos = this.getNearestBlock(closestBedPos);
                        }
                    }
                } else {
                    this.breakPos = closestBedPos;
                }
            }
            this.sendBlockBreak(this.breakPos);
        } else {
            this.blockDamage = 0;
            this.blockDamageCD = 1;
            this.bedPos = null;
            this.breakPos = null;
            this.resetSlot();
        }

        if (this.breakPos != null
                && !(mc.theWorld.getBlockState(this.breakPos).getBlock() instanceof BlockAir)
                && this.auraTarget() == null) {
            if (this.blockDamage == 0
                    || (this.blockDamage + mc.theWorld.getBlockState(this.breakPos).getBlock()
                    .getPlayerRelativeBlockHardness(mc.thePlayer, mc.theWorld, this.breakPos)) >= 1) {
                float[] rotations = getRotationFromPosition(
                        this.breakPos.getX() + 0.5, this.breakPos.getY() + 0.5, this.breakPos.getZ() + 0.5
                );
                event.setRotation(rotations[0], rotations[1], 10);
                if (!this.moveFix.getValue()) {
                    event.setPervRotation(mc.thePlayer.rotationYaw, 10);
                }
            }
        }
    }

    private static float[] getRotationFromPosition(double x, double y, double z) {
        double xDiff = x - mc.thePlayer.posX;
        double zDiff = z - mc.thePlayer.posZ;
        double yDiff = y - mc.thePlayer.posY - 1.5F;
        double dist = Math.sqrt(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float) (Math.atan2(zDiff, xDiff) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) -(Math.atan2(yDiff, dist) * 180.0D / Math.PI);
        return new float[]{yaw, pitch};
    }
private boolean isWhitelisted(BlockPos pos) {
        for (BlockPos bp : this.whitelisted) {
            double dx = bp.getX() - pos.getX();
            double dy = bp.getY() - pos.getY();
            double dz = bp.getZ() - pos.getZ();
            if (dx * dx + dy * dy + dz * dz < 1.5 * 1.5) {
                return true;
            }
        }
        return false;
    }

    // ported: BreakerWhitelistManager.onPlayerTick / onPacketReceive inlined
    private void updateWhitelist() {
        if (this.scanCheck && this.scanCooldown-- <= 0) {
            this.scanCooldown = 20;
            BlockPos bed = this.findNearestBedAnywhere(16);
            if (bed != null) {
                this.whitelisted.clear();
                this.whitelisted.add(bed);
                for (EnumFacing facing : EnumFacing.VALUES) {
                    this.whitelisted.add(bed.offset(facing));
                }
                this.scanCheck = false;
            }
        }
    }

    private BlockPos findNearestBedAnywhere(float distance) {
        float best = 69420.0F;
        BlockPos found = null;
        for (float x = -distance; x < distance; x++) {
            for (float y = -distance; y < distance; y++) {
                for (float z = -distance; z < distance; z++) {
                    BlockPos cPos = new BlockPos(
                            MathHelper.floor_double(mc.thePlayer.posX + x),
                            MathHelper.floor_double(mc.thePlayer.posY + y),
                            MathHelper.floor_double(mc.thePlayer.posZ + z)
                    );
                    if (mc.theWorld.getBlockState(cPos).getBlock() instanceof BlockBed) {
                        float dist = (float) mc.thePlayer.getDistance(cPos.getX() + 0.5, cPos.getY() + 0.5, cPos.getZ() + 0.5);
                        if (dist < best) {
                            best = dist;
                            found = cPos;
                        }
                    }
                }
            }
        }
        return found;
    }

    private boolean checkPosValidity(BlockPos pos) {
        if (pos == null) {
            return false;
        }
        return mc.thePlayer.getDistance(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 6;
    }

    private BlockPos findBed(float distance) {
        float bedDist = 69420.0F;
        BlockPos result = null;

        for (float x = -distance; x < distance; x++) {
            for (float z = -distance; z < distance; z++) {
                for (float y = -distance; y < distance; y++) {
                    BlockPos cPos = new BlockPos(
                            MathHelper.floor_double(mc.thePlayer.posX + x),
                            MathHelper.floor_double(mc.thePlayer.posY + y),
                            MathHelper.floor_double(mc.thePlayer.posZ + z)
                    );
                    if (mc.theWorld.getBlockState(cPos).getBlock() instanceof BlockBed) {
                        if (this.whitelist.getValue() && this.isWhitelisted(cPos)) {
                            continue;
                        }

                        double bcd = mc.thePlayer.getDistance(cPos.getX() + 0.5, cPos.getY() + 0.5, cPos.getZ() + 0.5);
                        if (bcd < bedDist) {
                            bedDist = (float) bcd;
                            result = cPos;
                        }
                    }
                }
            }
        }

        this.bedPos = result;
        return result;
    }

    private boolean isBedOpen(BlockPos pos) {
        BlockPos bedPart2 = null;
        for (BlockPos adjacentPos : new BlockPos[]{pos.north(), pos.south(), pos.east(), pos.west()}) {
            if (mc.theWorld.getBlockState(adjacentPos).getBlock() instanceof BlockBed) {
                bedPart2 = adjacentPos;
                break;
            }
        }
        if (bedPart2 == null) {
            return false;
        }
        return this.isNearbyAir(pos) || this.isNearbyAir(bedPart2);
    }
private boolean isNearbyAir(BlockPos pos) {
        for (BlockPos adjacentPos : new BlockPos[]{pos.up(), pos.south(), pos.east(), pos.west(), pos.north()}) {
            if (mc.theWorld.getBlockState(adjacentPos).getBlock() instanceof BlockAir) {
                return true;
            }
        }
        return false;
    }

    private BlockPos getNearestBlock(BlockPos pos) {
        double distance = 69.0;
        BlockPos nearest = null;

        for (BlockPos p : new ArrayList<BlockPos>(Arrays.asList(pos.up(), pos.west(), pos.south(), pos.east(), pos.north()))) {
            if (!(mc.theWorld.getBlockState(p).getBlock() instanceof BlockBed)
                    && mc.thePlayer.getDistance(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5) < distance) {
                nearest = p;
                distance = mc.thePlayer.getDistance(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5);
            }
        }
        return nearest;
    }

    private int getSlotFromBlock(Block block) {
        if (mc.thePlayer == null || mc.thePlayer.inventory == null) {
            return -1;
        }
        int bestSlot = -1;
        float bestSpeed = 1.0F;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
            if (stack == null) {
                continue;
            }

            float speed = stack.getStrVsBlock(block);
            if (speed > 1.0F) {
                int eff = EnchantmentHelper.getEnchantmentLevel(Enchantment.efficiency.effectId, stack);
                if (eff > 0) {
                    speed += (float) (eff * eff + 1);
                }
            }

            if (stack.getItem() instanceof ItemShears) {
                if (block instanceof BlockBed || block.getMaterial() == Material.cloth) {
                    speed = Math.max(speed, 5.0F);
                }
            }

            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }

        if (bestSlot == -1 && block instanceof BlockBed) {
            for (int i = 0; i < 9; i++) {
                ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
                if (stack != null && (stack.getItem() instanceof ItemShears
                        || stack.getItem() instanceof ItemAxe
                        || stack.getItem() instanceof ItemPickaxe)) {
                    bestSlot = i;
                    break;
                }
            }
        }

        return bestSlot;
    }
// ported: ProgressBarManager replaced by a simple RenderUtil rectangle bar at the same position
    @EventTarget
    public void onRender2D(Render2DEvent event) {
        boolean active = this.blockDamage > 0 && this.blockDamage < 1 && this.breakPos != null;
        if (!this.progressBar.getValue() || !active) {
            return;
        }

        ScaledResolution sr = new ScaledResolution(mc);
        float centerX = sr.getScaledWidth() / 2.0f;
        float textY = sr.getScaledHeight() / 2.0f + 13;

        float barWidth = 80.0f;
        float barHeight = 4.0f;
        float progress = Math.max(0.0f, Math.min(1.0f, this.blockDamage));

        RenderUtil.drawRect(centerX - barWidth / 2.0f, textY, centerX + barWidth / 2.0f, textY + barHeight, 0x80000000);
        RenderUtil.drawRect(
                centerX - barWidth / 2.0f, textY,
                centerX - barWidth / 2.0f + barWidth * progress, textY + barHeight,
                0xFF55FF55
        );
    }

    // ported: BreakerWhitelistManager.onPacketReceive ("Protect your bed" re-arms the whitelist scan)
    @EventTarget
    public void onPacketReceive(PacketEvent event) {
        if (event.getType() == EventType.RECEIVE && event.getPacket() instanceof S02PacketChat) {
            String text = ((S02PacketChat) event.getPacket()).getChatComponent().getUnformattedText();
            if (text.contains("Protect your bed")) {
                this.whitelisted.clear();
                this.scanCheck = true;
                this.scanCooldown = 0;
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.breakType.getModeString()};
    }
}