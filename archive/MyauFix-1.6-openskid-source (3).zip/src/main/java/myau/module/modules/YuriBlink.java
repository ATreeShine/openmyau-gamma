package myau.module.modules;

import myau.Myau;
import myau.enums.BlinkModules;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.LoadWorldEvent;
import myau.events.Render3DEvent;
import myau.events.UpdateEvent;
import myau.mixin.IAccessorRenderManager;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import myau.util.RenderUtil;
import myau.util.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.util.AxisAlignedBB;

// ported from ddlc.yuri.modules.impl.player.BlinkModule
// ported: Yuri's BlinkManager replaced by OpenMyau's Myau.blinkManager (same choke/flush semantics).
// ported: Yuri's "Cancel Received Packets" property is accepted but has no effect - OpenMyau's
// BlinkManager has no equivalent receive-side choke (only the stock Blink module does the same).
public class YuriBlink extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public final ModeProperty mode = new ModeProperty("Mode", 0, new String[]{"Constant", "Pulse"});
    public final IntProperty delay = new IntProperty("Delay", 20, 0, 100, () -> this.mode.getValue() == 1);
    public final BooleanProperty cancelReceivedPackets = new BooleanProperty("Cancel Received Packets", true);
    public final BooleanProperty renderBlinkPos = new BooleanProperty("Render Blink Pos", true);

    private double blinkedX;
    private double blinkedY;
    private double blinkedZ;
    private boolean hasStoredPosition = false;
    private final TimerUtil timer = new TimerUtil();

    public YuriBlink() {
        super("Yuri Blink", false);
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null) {
            return;
        }

        if (event.getType() != EventType.PRE) {
            // Yuri: BlinkManager.enable(...) every post-motion
            if (this.mode.getValue() == 0) {
                Myau.blinkManager.setBlinkState(true, BlinkModules.BLINK);
            } else {
                if (this.timer.hasTimeElapsed((Integer) this.delay.getValue() * 10L)) {
                    Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
                    this.timer.reset();
                } else {
                    Myau.blinkManager.setBlinkState(true, BlinkModules.BLINK);
                }
            }
        }

        if (event.getType() == EventType.PRE && !this.hasStoredPosition) {
            this.blinkedX = mc.thePlayer.posX;
            this.blinkedY = mc.thePlayer.posY;
            this.blinkedZ = mc.thePlayer.posZ;
            this.hasStoredPosition = true;
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (!this.hasStoredPosition || !this.renderBlinkPos.getValue() || mc.gameSettings.thirdPersonView == 0) {
            return;
        }

        IAccessorRenderManager renderManager = (IAccessorRenderManager) mc.getRenderManager();
        double x = this.blinkedX - renderManager.getRenderPosX();
        double y = this.blinkedY - renderManager.getRenderPosY();
        double z = this.blinkedZ - renderManager.getRenderPosZ();

        AxisAlignedBB bb = new AxisAlignedBB(
                x - 0.3, y, z - 0.3,
                x + 0.3, y + 1.8, z + 0.3
        );

        RenderUtil.enableRenderState();
        RenderUtil.drawBoundingBox(bb, 255, 255, 255, 255, 2.0F);
        RenderUtil.disableRenderState();
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.setEnabled(false);
    }

    @Override
    public void onDisabled() {
        Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
        this.hasStoredPosition = false;
    }

    @Override
    public void onEnabled() {
        Myau.blinkManager.setBlinkState(false, Myau.blinkManager.getBlinkingModule());
        Myau.blinkManager.setBlinkState(true, BlinkModules.BLINK);
        this.hasStoredPosition = false;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.mode.getModeString()};
    }
}