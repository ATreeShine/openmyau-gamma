package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.UpdateEvent;
import myau.module.Module;
import myau.property.properties.ModeProperty;
import myau.util.PacketUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

// ported from ddlc.yuri.modules.impl.movement.PhaseModule
// NORMAL: clip sideways into walls when collided / embedded; POLAR: downward motion collapse near ground
public class YuriPhase extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public final ModeProperty mode = new ModeProperty("Mode", 0, new String[]{"Normal", "Polar"});

    private boolean phasing;
    private int offGroundTicks;

    public YuriPhase() {
        super("Yuri Phase", false);
    }

    // ported: Yuri PlayerUtils.insideBlock()
    private static boolean insideBlock() {
        if (mc.thePlayer.ticksExisted < 5) {
            return false;
        }

        EntityPlayerSP player = mc.thePlayer;
        AxisAlignedBB bb = player.getEntityBoundingBox();
        for (int x = MathHelper.floor_double(bb.minX); x < MathHelper.floor_double(bb.maxX) + 1; ++x) {
            for (int y = MathHelper.floor_double(bb.minY); y < MathHelper.floor_double(bb.maxY) + 1; ++y) {
                for (int z = MathHelper.floor_double(bb.minZ); z < MathHelper.floor_double(bb.maxZ) + 1; ++z) {
                    BlockPos pos = new BlockPos(x, y, z);
                    Block block = mc.theWorld.getBlockState(pos).getBlock();
                    if (block != null && !(block instanceof BlockAir)) {
                        AxisAlignedBB collision = block.getCollisionBoundingBox(mc.theWorld, pos, mc.theWorld.getBlockState(pos));
                        if (collision != null && player.getEntityBoundingBox().intersectsWith(collision)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    // ported: Yuri PlayerUtils.blockNear(range) - any non-air block within range
    private static boolean blockNear(int range) {
        BlockPos base = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
        for (int x = -range; x <= range; ++x) {
            for (int y = -range; y <= range; ++y) {
                for (int z = -range; z <= range; ++z) {
                    Block block = mc.theWorld.getBlockState(base.add(x, y, z)).getBlock();
                    if (!(block instanceof BlockAir)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // ported: Yuri MoveUtils.findGround(player) - Y of first non-air block below
    private static double findGround() {
        int baseX = MathHelper.floor_double(mc.thePlayer.posX);
        int baseZ = MathHelper.floor_double(mc.thePlayer.posZ);
        for (int i = 0; i < 50; i++) {
            BlockPos pos = new BlockPos(baseX, MathHelper.floor_double(mc.thePlayer.posY) - i, baseZ);
            if (!(mc.theWorld.getBlockState(pos).getBlock() instanceof BlockAir)) {
                return pos.getY();
            }
        }
        return 0.0;
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (event.getType() != EventType.PRE || mc.thePlayer == null || mc.theWorld == null) {
            return;
        }

        if (mc.thePlayer.onGround) {
            this.offGroundTicks = 0;
        } else {
            this.offGroundTicks++;
        }

        if (this.mode.getValue() == 0) {
            this.phasing = false;

            final double rotation = Math.toRadians(mc.thePlayer.rotationYaw);

            final double x = Math.sin(rotation);
            final double z = Math.cos(rotation);

            if (mc.thePlayer.isCollidedHorizontally) {
                mc.thePlayer.setPosition(mc.thePlayer.posX - x * 0.005, mc.thePlayer.posY, mc.thePlayer.posZ + z * 0.005);
                this.phasing = true;
            } else if (insideBlock()) {
                PacketUtil.sendPacketNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(
                        mc.thePlayer.posX - x * 1.5, mc.thePlayer.posY, mc.thePlayer.posZ + z * 1.5, false));

                mc.thePlayer.motionX *= 0.3D;
                mc.thePlayer.motionZ *= 0.3D;

                this.phasing = true;
            }
        }

        if (this.mode.getValue() == 1 && blockNear(2) && mc.gameSettings.keyBindJump.isKeyDown()) {
            double ground = mc.thePlayer.posY - findGround();

            boolean movingMotion = Math.abs(mc.thePlayer.motionX) > 0.03 || Math.abs(mc.thePlayer.motionZ) > 0.03;

            if (!movingMotion && mc.thePlayer.motionY < 0 && ground < 1.26) {
                mc.thePlayer.motionY -= 0.091F;
                // ported: Yuri also set MotionEvent.onGround when ground < 1.1 - no onGround
                // field on OpenMyau's update event, approximated with an on-ground position packet
                if (ground < 1.1) {
                    PacketUtil.sendPacketNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(
                            mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, true));
                }
            }
        }

        this.handleSneakFix();
    }

    private void handleSneakFix() {
        if (!mc.thePlayer.isSneaking()) {
            return;
        }

        final double wDist = 0.00001D;
        final double aDist = 0.00001D;
        final double sDist = -0.00001D;
        final double dDist = -0.00001D;

        final double rotation = Math.toRadians(mc.thePlayer.rotationYaw);

        if (mc.gameSettings.keyBindForward.isKeyDown()) {
            final double xx = Math.sin(rotation) * wDist;
            final double zz = Math.cos(rotation) * wDist;

            mc.thePlayer.setPosition(mc.thePlayer.posX - xx, mc.thePlayer.posY, mc.thePlayer.posZ + zz);
        }

        if (mc.gameSettings.keyBindLeft.isKeyDown()) {
            final double xx = Math.sin(rotation) * aDist;

            mc.thePlayer.setPosition(mc.thePlayer.posX + xx, mc.thePlayer.posY, mc.thePlayer.posZ);
        }

        if (mc.gameSettings.keyBindBack.isKeyDown()) {
            final double xx = Math.sin(rotation) * sDist;
            final double zz = Math.cos(rotation) * sDist;

            mc.thePlayer.setPosition(mc.thePlayer.posX - xx, mc.thePlayer.posY, mc.thePlayer.posZ + zz);
        }

        if (mc.gameSettings.keyBindRight.isKeyDown()) {
            final double zz = Math.sin(rotation) * dDist;

            mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ + zz);
        }
    }

    @Override
    public void onEnabled() {
        this.phasing = false;
        this.offGroundTicks = 0;
    }

    @Override
    public void onDisabled() {
        this.phasing = false;
        this.offGroundTicks = 0;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.mode.getModeString()};
    }
}

