package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.LivingUpdateEvent;
import myau.events.PacketEvent;
import myau.events.StrafeEvent;
import myau.events.UpdateEvent;
import myau.mixin.IAccessorEntity;
import myau.mixin.IAccessorKeyBinding;
import myau.mixin.IAccessorMinecraft;
import myau.module.Module;
import myau.property.properties.FloatProperty;
import myau.property.properties.ModeProperty;
import myau.util.MoveUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.potion.Potion;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Timer;

// ported from ddlc.yuri.modules.impl.movement.SpeedModule + its six SpeedMode impls.
// Vanilla/Legit/Polar/Intave/NCP/Librecraft in one module, mirroring Yuri's mode enum.
// Librecraft uses the public EntityLivingBase.jumpMovementFactor field; NCP's offGroundTicks
// (a Yuri-added field on its patched EntityPlayerSP) is tracked locally as airTicks instead.
public class YuriSpeed extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    // ported: Yuri NumberProperty("Speed", 0.9, 0.1, 5.0, 0.1, visibleWhen mode == VANILLA)
    public final FloatProperty speed = new FloatProperty("Speed", 0.9F, 0.1F, 5.0F, () -> this.mode.getValue() == 0);

    public final ModeProperty mode = new ModeProperty(
            "Mode", 0,
            new String[]{"Vanilla", "Legit", "Polar", "Intave", "NCP", "Librecraft"}
    );

    private int airTicks = 0;
    private int librecraftTicks = 0;
    private boolean librecraftTimer = false;
    private float polarFriction = 1.0F;
    private int ncpFlagTicks = 0;
    private boolean ncpFlag = false;

    public YuriSpeed() {
        super("Yuri Speed", false);
    }

    private boolean inLiquidOrWeb() {
        return mc.thePlayer.isInWater()
                || mc.thePlayer.isInLava()
                || ((IAccessorEntity) mc.thePlayer).getIsInWeb();
    }

    private void resetAirTicks() {
        if (mc.thePlayer.onGround) {
            this.airTicks = 0;
        } else {
            this.airTicks++;
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (event.getType() != EventType.PRE || mc.thePlayer == null) {
            return;
        }
        resetAirTicks();

        switch (this.mode.getValue()) {
            case 1:
                this.legitPre(event);
                break;
            case 3:
                this.intavePre();
                break;
            case 4:
                this.ncpPre();
                break;
            case 5:
                this.librecraftPre();
                break;
            default:
                break;
        }
    }

    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (mc.thePlayer == null) {
            return;
        }
        switch (this.mode.getValue()) {
            case 0:
                this.vanillaStrafe(event);
                break;
            case 1:
                this.legitStrafe();
                break;
            case 2:
                this.polarStrafe(event);
                break;
            case 3:
                this.intaveStrafe();
                break;
            default:
                break;
        }
    }

    @EventTarget
    public void onPacketReceive(PacketEvent event) {
        if (event.getType() != EventType.RECEIVE || mc.thePlayer == null) {
            return;
        }
        if (event.getPacket() instanceof S08PacketPlayerPosLook) {
            if (this.mode.getValue() == 2 && mc.thePlayer.onGround) {
                this.polarFriction = 1.0F;
            } else if (this.mode.getValue() == 4) {
                this.ncpFlag = true;
            }
        }
    }

    // --- VANILLA ---
    private void vanillaStrafe(StrafeEvent event) {
        if (MoveUtil.isMoving() && mc.thePlayer.onGround) {
            mc.thePlayer.jump();
        }
        float target = this.speed.getValue();
        if (event.getForward() != 0.0F && event.getStrafe() != 0.0F) {
            target *= 0.98F;
        }
        event.setFriction(target);
        mc.thePlayer.motionX = 0.0;
        mc.thePlayer.motionZ = 0.0;
    }

    // --- LEGIT ---
    private void legitStrafe() {
        if (MoveUtil.isMoving() && mc.thePlayer.onGround
                && !GameSettings.isKeyDown(mc.gameSettings.keyBindJump) && !inLiquidOrWeb()) {
            mc.thePlayer.jump();
        }
    }

    private void legitPre(UpdateEvent event) {
        if (MoveUtil.isMoving() && mc.thePlayer.onGround
                && !GameSettings.isKeyDown(mc.gameSettings.keyBindJump) && !inLiquidOrWeb()) {
            event.setRotation(MoveUtil.getMoveYaw(), mc.thePlayer.rotationPitch, 2);
        }
    }

    // --- POLAR ---
    private void polarStrafe(StrafeEvent event) {
        if (MoveUtil.isMoving() && mc.thePlayer.onGround
                && !GameSettings.isKeyDown(mc.gameSettings.keyBindJump) && !inLiquidOrWeb()) {
            mc.thePlayer.jump();
        }
        this.polarFriction = mc.gameSettings.keyBindLeft.isKeyDown()
                || mc.gameSettings.keyBindRight.isKeyDown() ? 1.017F : 1.033F;
        event.setFriction(event.getFriction() * this.polarFriction);
    }

    // --- INTAVE ---
    private void intaveStrafe() {
        if (MoveUtil.isMoving() && mc.thePlayer.onGround
                && !GameSettings.isKeyDown(mc.gameSettings.keyBindJump) && !inLiquidOrWeb()) {
            mc.thePlayer.jump();
        }
    }

    private void intavePre() {
        switch (this.airTicks) {
            case 1:
                mc.thePlayer.motionX *= 1.005;
                mc.thePlayer.motionZ *= 1.005;
                break;
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                mc.thePlayer.motionX *= 1.011;
                mc.thePlayer.motionZ *= 1.001;
                break;
            default:
                break;
        }
        if (this.airTicks == 1) {
            mc.thePlayer.motionX *= 1.0045;
            mc.thePlayer.motionZ *= 1.0045;
        }
        Timer timer = ((IAccessorMinecraft) mc).getTimer();
        if (timer != null) {
            timer.timerSpeed = 1.0075F;
        }
    }

    // --- NCP ---
    private void ncpPre() {
        if (this.ncpFlag) {
            this.ncpFlagTicks++;
        }
        if (this.ncpFlagTicks > 60) {
            this.ncpFlagTicks = 0;
            this.ncpFlag = false;
        }
        if (this.ncpFlag) {
            return;
        }

        if (!MoveUtil.isMoving() || mc.thePlayer.isInWater()) {
            return;
        }

        if (mc.thePlayer.onGround && !GameSettings.isKeyDown(mc.gameSettings.keyBindJump)) {
            mc.thePlayer.jump();
        }
if (this.airTicks == 2 && mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            MoveUtil.setSpeed(0.48D, MoveUtil.getMoveYaw());
        } else if (this.airTicks == 2) {
            MoveUtil.setSpeed(0.3222259D, MoveUtil.getMoveYaw());
        } else if (this.airTicks >= 8 && this.airTicks <= 9) {
            mc.thePlayer.motionY -= 0.07F;
        } else {
            MoveUtil.setSpeed(MoveUtil.getSpeed(), MoveUtil.getMoveYaw());
        }
    }

    // --- LIBRECRAFT ---
    private void librecraftPre() {
        this.librecraftTicks++;

        if (this.librecraftTicks == 4) {
            mc.thePlayer.motionY = -0.098F;
        }

        if (this.librecraftTimer) {
            Timer timer = ((IAccessorMinecraft) mc).getTimer();
            if (timer != null) {
                timer.timerSpeed = 1.0F;
            }
            this.librecraftTimer = false;
        }

        float movingYaw = MoveUtil.getMoveYaw();
        boolean straight = Math.abs(mc.thePlayer.moveStrafing) < 0.1F
                || Math.abs(MathHelper.wrapAngleTo180_float(movingYaw)) < 45.0F;

        mc.thePlayer.jumpMovementFactor = straight ? 0.026499F : 0.0244F;
        ((IAccessorKeyBinding) mc.gameSettings.keyBindJump)
                .setPressed(GameSettings.isKeyDown(mc.gameSettings.keyBindJump));

        if (MoveUtil.getSpeed() < 0.215 && !mc.thePlayer.onGround) {
            MoveUtil.setSpeed(0.215D, MoveUtil.getMoveYaw());
        }

        if (mc.thePlayer.onGround && MoveUtil.isMoving()) {
            this.librecraftTicks = 0;
            ((IAccessorKeyBinding) mc.gameSettings.keyBindJump).setPressed(false);
            mc.thePlayer.jump();

            if (!mc.thePlayer.isAirBorne) {
                return;
            }

            Timer timer = ((IAccessorMinecraft) mc).getTimer();
            if (timer != null) {
                timer.timerSpeed = 1.25F;
            }
            this.librecraftTimer = true;

            MoveUtil.setSpeed(MoveUtil.getSpeed(), MoveUtil.getMoveYaw());
            if (MoveUtil.getSpeed() < 0.5) {
                MoveUtil.setSpeed(0.4849D, MoveUtil.getMoveYaw());
            }
        }
    }

    @EventTarget
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null) {
            return;
        }
        if (this.mode.getValue() == 3 || this.mode.getValue() == 5) {
            mc.thePlayer.movementInput.jump = false;
        }
    }

    @Override
    public void onDisabled() {
        Timer timer = ((IAccessorMinecraft) mc).getTimer();
        if (timer != null) {
            timer.timerSpeed = 1.0F;
        }
        this.librecraftTimer = false;
        this.librecraftTicks = 0;
        this.ncpFlag = false;
        this.ncpFlagTicks = 0;
        this.polarFriction = 1.0F;
        this.airTicks = 0;
        mc.thePlayer.jumpMovementFactor = 0.2F;
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.mode.getModeString()};
    }
}
