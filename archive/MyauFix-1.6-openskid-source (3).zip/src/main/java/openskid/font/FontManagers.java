package openskid.font;

import openskid.font.impl.UFontRenderer;

import java.util.HashMap;
import java.util.Map;

/**
 * Font registry for the imported OpenSkid modules.
 *
 * <p>Upstream OpenSkid eagerly built nine {@link UFontRenderer} instances in {@link #load()}, which
 * Myau called straight from {@code Myau.init()}. That was unsafe here: every {@code UFontRenderer}
 * constructor dereferences {@code Minecraft.getMinecraft()}, so the whole client would die during
 * startup if Myau were constructed before the Minecraft instance existed. Nothing outside this class
 * uses the named size fields (callers go through {@link #getFont(int)}), so construction is now
 * lazy and happens on first use, at which point Minecraft is guaranteed to exist.</p>
 */
public class FontManagers {

    private static final String DEFAULT_FONT = "NotoSansSC-Regular";

    private static final int[] SIZES = {14, 16, 18, 20, 22, 24, 28, 36, 40};

    private final Map<Integer, UFontRenderer> fonts = new HashMap<>();

    private boolean loaded;

    public UFontRenderer s14;
    public UFontRenderer s16;
    public UFontRenderer s18;
    public UFontRenderer s20;
    public UFontRenderer s22;
    public UFontRenderer s24;
    public UFontRenderer s28;
    public UFontRenderer s36;
    public UFontRenderer s40;

    /**
     * Builds the named sizes on first call. Kept for source compatibility with upstream; the work
     * is deferred until a size is actually requested.
     */
    public synchronized void load() {
        if (this.loaded) {
            return;
        }
        this.loaded = true;
        for (int size : SIZES) {
            getFont(size);
        }
    }

    public synchronized UFontRenderer getFont(int size) {
        UFontRenderer cached = this.fonts.get(size);
        if (cached != null) {
            return cached;
        }
        UFontRenderer font = new UFontRenderer(DEFAULT_FONT, size);
        this.fonts.put(size, font);
        switch (size) {
            case 14: this.s14 = font; break;
            case 16: this.s16 = font; break;
            case 18: this.s18 = font; break;
            case 20: this.s20 = font; break;
            case 22: this.s22 = font; break;
            case 24: this.s24 = font; break;
            case 28: this.s28 = font; break;
            case 36: this.s36 = font; break;
            case 40: this.s40 = font; break;
            default: break;
        }
        return font;
    }
}