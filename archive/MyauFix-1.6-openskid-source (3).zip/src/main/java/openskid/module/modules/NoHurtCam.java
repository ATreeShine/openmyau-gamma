package openskid.module.modules;

import myau.module.Module;
import myau.property.properties.PercentProperty;

public class NoHurtCam extends Module {
    public final PercentProperty multiplier = new PercentProperty("multiplier", 0);

    public NoHurtCam() {
        super("openskid-NoHurtCam", false, true, "Removes or reduces the hurt camera shake.");
    }
}
