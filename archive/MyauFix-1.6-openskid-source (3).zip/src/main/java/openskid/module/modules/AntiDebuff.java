package openskid.module.modules;

import myau.module.Module;
import myau.property.properties.BooleanProperty;

public class AntiDebuff extends Module {
    public final BooleanProperty blindness = new BooleanProperty("blindness", true);
    public final BooleanProperty nausea = new BooleanProperty("nausea", true);

    public AntiDebuff() {
        super("openskid-AntiDebuff", false, false, "Removes blindness and nausea potion effects.");
    }
}
