package openskid.module.modules;

import myau.event.EventTarget;
import myau.events.MoveInputEvent;
import myau.management.RotationState;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import openskid.util.MoveUtil;
import net.minecraft.client.Minecraft;

public class MoveFix extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public final BooleanProperty groundOnly = new BooleanProperty("ground-only", false);

    public MoveFix() {
        super("openskid-MoveFix", false, false, "Fixes movement inputs while silent rotations are active.");
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null) {
            return;
        }
        if (this.groundOnly.getValue() && !mc.thePlayer.onGround) {
            return;
        }
        if (RotationState.isActived() && MoveUtil.isForwardPressed()) {
            MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
        }
    }
}
